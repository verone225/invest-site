import { createHmac, timingSafeEqual } from "node:crypto";

const COOKIE_NAME = "anywheel_admin_session";
const MAX_AGE_SECONDS = 60 * 60 * 8;
const secret = () => process.env.JWT_SECRET || "demo-admin-secret";

export function createAdminSession(phone: string) {
  const payload = Buffer.from(JSON.stringify({ phone, exp: Math.floor(Date.now() / 1000) + MAX_AGE_SECONDS })).toString("base64url");
  const signature = createHmac("sha256", secret()).update(payload).digest("base64url");
  return { value: `${payload}.${signature}`, maxAge: MAX_AGE_SECONDS };
}

export function hasValidAdminSession(cookieHeader: string | undefined) {
  const raw = cookieHeader?.split(";").map(item => item.trim()).find(item => item.startsWith(`${COOKIE_NAME}=`))?.split("=")[1];
  if (!raw) return false;
  const [payload, signature] = raw.split(".");
  if (!payload || !signature) return false;
  const expected = createHmac("sha256", secret()).update(payload).digest("base64url");
  if (signature.length !== expected.length || !timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) return false;
  try { const parsed = JSON.parse(Buffer.from(payload, "base64url").toString("utf8")); return parsed.phone === "+2250544894579" && parsed.exp > Math.floor(Date.now() / 1000); } catch { return false; }
}

export { COOKIE_NAME, MAX_AGE_SECONDS };
