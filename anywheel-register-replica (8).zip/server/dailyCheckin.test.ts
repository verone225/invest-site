import { describe, expect, it } from "vitest";
import { DAILY_CHECKIN_BONUS, claimDailyCheckin } from "../client/src/lib/dailyCheckin";

function createStorage() {
  const values = new Map<string, string>();
  return {
    getItem: (key: string) => values.get(key) ?? null,
    setItem: (key: string, value: string) => values.set(key, value),
    removeItem: (key: string) => values.delete(key),
    clear: () => values.clear(),
    key: (index: number) => Array.from(values.keys())[index] ?? null,
    get length() { return values.size; },
  } as Storage;
}

describe("daily check-in", () => {
  it("credits 50 FCFA once per day", () => {
    const storage = createStorage();
    const date = new Date("2026-08-18T10:00:00Z");
    expect(claimDailyCheckin(storage, date)).toEqual({ claimed: true, bonusTotal: DAILY_CHECKIN_BONUS });
    expect(claimDailyCheckin(storage, date)).toEqual({ claimed: false, bonusTotal: DAILY_CHECKIN_BONUS });
    expect(claimDailyCheckin(storage, new Date("2026-08-19T10:00:00Z"))).toEqual({ claimed: true, bonusTotal: DAILY_CHECKIN_BONUS * 2 });
  });
});
