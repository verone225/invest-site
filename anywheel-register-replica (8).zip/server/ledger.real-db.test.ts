import { afterEach, describe, expect, it } from "vitest";
import { eq, inArray } from "drizzle-orm";
import { demoAccounts, demoLedger, demoPurchases, demoTransactions } from "../drizzle/schema";
import { getDb } from "./db";
import { appRouter } from "./routers";
import { createAdminSession } from "./adminSession";
import type { TrpcContext } from "./_core/context";

const phones = ["+2250787654321", "+2250787654322"];
const adminSession = createAdminSession("+2250544894579");
const userCtx = { req: { protocol: "https", headers: {} } as TrpcContext["req"], res: {} as TrpcContext["res"], user: undefined } as TrpcContext;
const adminCtx = { req: { protocol: "https", headers: { cookie: `anywheel_admin_session=${adminSession.value}` } } as TrpcContext["req"], res: {} as TrpcContext["res"], user: undefined } as TrpcContext;

async function cleanup() {
  const db = await getDb();
  if (!db) return;
  await db.delete(demoPurchases).where(inArray(demoPurchases.accountPhone, phones));
  await db.delete(demoLedger).where(inArray(demoLedger.accountPhone, phones));
  await db.delete(demoTransactions).where(inArray(demoTransactions.accountPhone, phones));
  await db.delete(demoAccounts).where(inArray(demoAccounts.phone, phones));
}

describe.skipIf(!process.env.DATABASE_URL)("real account ledger", () => {
  afterEach(cleanup);
  it("separates accounts, credits referral revenue and exposes withdrawal details", async () => {
    const user = appRouter.createCaller(userCtx);
    const admin = appRouter.createCaller(adminCtx);
    for (const phone of phones) await user.demoAccount.signIn({ mode: "register", phone, code: "010101", confirmCode: "010101", inviteCode: "d9s3p7" });
    const beforeA = await user.demoAccount.portfolio({ phone: phones[0] });
    const beforeB = await user.demoAccount.portfolio({ phone: phones[1] });
    await admin.admin.creditReferral({ accountPhone: phones[0], amount: 3000, detail: "Commission de parrainage de test" });
    const afterA = await user.demoAccount.portfolio({ phone: phones[0] });
    const afterB = await user.demoAccount.portfolio({ phone: phones[1] });
    expect(afterA.balanceCfa).toBe(beforeA.balanceCfa + 3000);
    expect(afterA.referralRevenueCfa).toBe(beforeA.referralRevenueCfa + 3000);
    expect(afterB.balanceCfa).toBe(beforeB.balanceCfa);
    await expect(user.demoAccount.createTransaction({ accountPhone: phones[0], type: "withdrawal", phone: "+2250700000000", amount: 1500 })).rejects.toThrow(/achet.*produit/i);
    await expect(user.demoAccount.purchaseProduct({ accountPhone: phones[1], productName: "VIP1 Anywheel Bike", amount: 3000 })).rejects.toThrow(/solde insuffisant/i);
    await user.demoAccount.purchaseProduct({ accountPhone: phones[0], productName: "VIP1 Anywheel Bike", amount: 3000 });
    const afterPurchase = await user.demoAccount.portfolio({ phone: phones[0] });
    expect(afterPurchase.balanceCfa).toBe(afterA.balanceCfa - 3000);
    expect(afterPurchase.balanceCfa).toBe(beforeA.balanceCfa);
    expect(afterPurchase.ledger.some(entry => entry.kind === "purchase" && entry.direction === "debit" && entry.amount === 3000)).toBe(true);
    const withdrawal = await user.demoAccount.createTransaction({ accountPhone: phones[0], type: "withdrawal", phone: "+2250700000000", amount: 1500 });
    await admin.admin.updateStatus({ id: withdrawal.id!, status: "approved" });
    const history = await user.demoAccount.history({ phone: phones[0] });
    const detail = history.find(entry => entry.transactionId === withdrawal.id);
    expect(detail?.phone).toBe("+2250700000000");
    expect(detail?.status).toBe("approved");
  });
});
