import { afterEach, describe, expect, it } from "vitest";
import { eq } from "drizzle-orm";
import { demoAccounts, demoLedger, demoTransactions } from "../drizzle/schema";
import { getDb } from "./db";
import { appRouter } from "./routers";
import { createAdminSession } from "./adminSession";
import type { TrpcContext } from "./_core/context";

const phone = "+2250787654399";
const session = createAdminSession("+2250544894579");
const ctx = { req: { protocol: "https", headers: { cookie: `anywheel_admin_session=${session.value}` } } as TrpcContext["req"], res: {} as TrpcContext["res"], user: undefined } as TrpcContext;

async function cleanup() {
  const db = await getDb();
  if (db) {
    await db.delete(demoLedger).where(eq(demoLedger.accountPhone, phone));
    await db.delete(demoTransactions).where(eq(demoTransactions.phone, phone));
    await db.delete(demoAccounts).where(eq(demoAccounts.phone, phone));
  }
}

describe.skipIf(!process.env.DATABASE_URL)("real database admin transactions", () => {
  afterEach(cleanup);
  it("persists a transaction, exposes the full number and persists status", async () => {
    const caller = appRouter.createCaller(ctx);
    await caller.demoAccount.signIn({ mode: "register", phone, code: "010101", confirmCode: "010101", inviteCode: "d9s3p7" });
    const before = await caller.demoAccount.portfolio({ phone });
    const created = await caller.demoAccount.createTransaction({ accountPhone: phone, type: "deposit", phone, amount: 3000 });
    expect(created.phone).toBe(phone);
    const listed = await caller.admin.transactions();
    expect(listed.some(item => item.id === created.id && item.phone === phone)).toBe(true);
    await caller.admin.updateStatus({ id: created.id!, status: "approved" });
    const refreshed = await caller.admin.transactions();
    expect(refreshed.find(item => item.id === created.id)?.status).toBe("approved");
    const after = await caller.demoAccount.portfolio({ phone });
    expect(after.balanceCfa).toBe((before.balanceCfa ?? 1500) + 3000);
    expect((await caller.demoAccount.history({ phone })).some(entry => entry.transactionId === created.id && entry.kind === "deposit")).toBe(true);
  });
});
