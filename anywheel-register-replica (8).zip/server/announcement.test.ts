// @vitest-environment jsdom
import React from "react";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { AnnouncementModal } from "../client/src/pages/Home";

afterEach(() => cleanup());

describe("announcement interaction", () => {
  it("closes when clicking outside while preserving the modal on inner clicks", () => {
    const onClose = vi.fn();
    render(React.createElement(AnnouncementModal, { onClose }));
    const backdrop = screen.getByRole("dialog");
    fireEvent.mouseDown(backdrop);
    expect(onClose).toHaveBeenCalledOnce();
    fireEvent.mouseDown(screen.getByRole("heading", { name: /lancement officiel/i }));
    expect(onClose).toHaveBeenCalledOnce();
  });

  it("calls the close handler when the user enters the home page", () => {
    const onClose = vi.fn();
    render(React.createElement(AnnouncementModal, { onClose }));
    expect(screen.getByRole("dialog")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: /Accéder à l’accueil/i }));
    expect(onClose).toHaveBeenCalledOnce();
  });
});
