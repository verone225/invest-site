import { afterEach, describe, expect, it } from "vitest";
import { eq, inArray } from "drizzle-orm";
import { demoAccounts, demoLedger, demoPurchases } from "../drizzle/schema";
import { getDb } from "./db";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

const phone = "+2250787654388";
const childPhone = "+2250787654387";
const ctx = { req: { protocol: "https", headers: {} } as TrpcContext["req"], res: {} as TrpcContext["res"], user: undefined } as TrpcContext;

async function cleanup() {
  const db = await getDb();
  if (!db) return;
  await db.delete(demoPurchases).where(inArray(demoPurchases.accountPhone, [phone, childPhone]));
  await db.delete(demoLedger).where(inArray(demoLedger.accountPhone, [phone, childPhone]));
  await db.delete(demoAccounts).where(inArray(demoAccounts.phone, [phone, childPhone]));
}

describe.skipIf(!process.env.DATABASE_URL)("account authentication and referral attribution", () => {
  afterEach(cleanup);
  it("persists accounts, validates credentials and credits the sponsor", async () => {
    const caller = appRouter.createCaller(ctx);
    await caller.demoAccount.signIn({ mode: "register", phone, code: "010101", confirmCode: "010101", inviteCode: "d9s3p7" });
    const sponsorPortfolio = await caller.demoAccount.portfolio({ phone });
    expect(sponsorPortfolio.inviteCode).toMatch(/^AW/);
    expect(sponsorPortfolio.balanceCfa).toBe(1500);
    expect(sponsorPortfolio.cumulativeRevenueCfa).toBe(1500);
    expect(sponsorPortfolio.ledger.some(entry => entry.kind === "signup_bonus" && entry.amount === 1500)).toBe(true);

    await caller.demoAccount.signIn({ mode: "register", phone: childPhone, code: "010101", confirmCode: "010101", inviteCode: sponsorPortfolio.inviteCode });
    await expect(caller.demoAccount.signIn({ mode: "login", phone: childPhone, code: "010101", confirmCode: "010101", inviteCode: "login" })).resolves.toMatchObject({ phone: childPhone, balanceCfa: 1500, cumulativeRevenueCfa: 1500 });
    const sponsorAfterReferral = await caller.demoAccount.portfolio({ phone });
    expect(sponsorAfterReferral.referralRevenueCfa).toBe(585);
    expect(sponsorAfterReferral.balanceCfa).toBe(2085);
    expect(sponsorAfterReferral.ledger.some(entry => entry.kind === "referral" && entry.amount === 585 && entry.detail.includes(childPhone))).toBe(true);

    await caller.demoAccount.purchaseProduct({ accountPhone: childPhone, productName: "VIP1 Anywheel Bike", amount: 1000 });
    const sponsorAfterPurchase = await caller.demoAccount.portfolio({ phone });
    expect(sponsorAfterPurchase.referralRevenueCfa).toBe(975);
    expect(sponsorAfterPurchase.balanceCfa).toBe(2475);
    expect(sponsorAfterPurchase.ledger.some(entry => entry.kind === "referral" && entry.amount === 390 && entry.detail.includes("VIP1"))).toBe(true);

    await expect(caller.demoAccount.signIn({ mode: "register", phone: "+2250787654386", code: "010101", confirmCode: "010101", inviteCode: "unknown" })).rejects.toThrow("parrain déjà inscrit");
    await expect(caller.demoAccount.signIn({ mode: "login", phone: "+2250787654386", code: "010101", confirmCode: "010101", inviteCode: "login" })).rejects.toThrow("incorrect");
    await expect(caller.demoAccount.signIn({ mode: "login", phone: childPhone, code: "999999", confirmCode: "999999", inviteCode: "login" })).rejects.toThrow("incorrect");
    await expect(caller.demoAccount.changeCode({ accountPhone: childPhone, currentCode: "999999", newCode: "121212", confirmCode: "121212" })).rejects.toThrow("ancien code");
    await expect(caller.demoAccount.changeCode({ accountPhone: childPhone, currentCode: "010101", newCode: "121212", confirmCode: "121213" })).rejects.toThrow("ne correspondent pas");
    await expect(caller.demoAccount.changeCode({ accountPhone: childPhone, currentCode: "010101", newCode: "010101", confirmCode: "010101" })).rejects.toThrow("différent");
    await expect(caller.demoAccount.changeCode({ accountPhone: childPhone, currentCode: "010101", newCode: "121212", confirmCode: "121212" })).resolves.toMatchObject({ phone: childPhone, updated: true });
    await expect(caller.demoAccount.signIn({ mode: "login", phone: childPhone, code: "010101", confirmCode: "010101", inviteCode: "login" })).rejects.toThrow("incorrect");
    await expect(caller.demoAccount.signIn({ mode: "login", phone: childPhone, code: "121212", confirmCode: "121212", inviteCode: "login" })).resolves.toMatchObject({ phone: childPhone });
  });
});
