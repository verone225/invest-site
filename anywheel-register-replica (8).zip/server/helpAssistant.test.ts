import { describe, expect, it } from "vitest";
import { answerHelpQuestion } from "../client/src/lib/helpAssistant";

describe("help assistant knowledge", () => {
  it("answers deposit questions with Wave and the allowed amounts", () => {
    const result = answerHelpQuestion("Comment faire un dépôt avec Wave ?");
    expect(result.topic).toBe("deposit");
    expect(result.answer).toContain("3 000, 10 000 ou 25 000 FCFA");
  });

  it("answers withdrawal and code questions from the platform rules", () => {
    const withdrawalAnswer = answerHelpQuestion("Quel est le minimum de retrait ?").answer;
    expect(withdrawalAnswer).toContain("1 500 FCFA");
    expect(withdrawalAnswer).toContain("20 %");
    expect(withdrawalAnswer).toContain("4 à 24 heures");
    expect(withdrawalAnswer).toContain("produit");
    expect(answerHelpQuestion("Comment modifier le code ?").answer).toContain("6 chiffres");
  });

  it("does not mention administration in chat answers", () => {
    const topics = ["inscription", "dépôt", "retrait", "produit", "pointage", "parrainage", "historique", "code", "à propos", "question générale"];
    for (const question of topics) expect(answerHelpQuestion(question).answer.toLocaleLowerCase("fr-FR")).not.toContain("administrateur");
  });
});
