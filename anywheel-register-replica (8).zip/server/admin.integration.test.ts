import { describe, expect, it, vi } from "vitest";
import { createAdminSession } from "./adminSession";
import type { TrpcContext } from "./_core/context";

const store: Array<{ id: number; type: "deposit" | "withdrawal"; phone: string; amount: number; status: "pending" | "approved" | "rejected"; createdAt: Date; updatedAt: Date }> = [];
vi.mock("./db", () => ({
  createDemoTransaction: vi.fn(async (input: { type: "deposit" | "withdrawal"; phone: string; amount: number }) => { const item = { id: store.length + 1, ...input, status: "pending" as const, createdAt: new Date(), updatedAt: new Date() }; store.unshift(item); return item; }),
  listDemoTransactions: vi.fn(async () => store),
  updateDemoTransactionStatus: vi.fn(async (id: number, status: "pending" | "approved" | "rejected") => { const item = store.find(row => row.id === id); if (item) item.status = status; return item; }),
  createDemoAccount: vi.fn(),
  getDemoAccountByPhone: vi.fn(async (phone: string) => ({ phone, balanceCfa: 1500, cumulativeRevenueCfa: 1500, referralRevenueCfa: 0 })),
}));

const { appRouter } = await import("./routers");
const baseCtx = { req: { protocol: "https", headers: {} } as TrpcContext["req"], res: { cookie: () => undefined } as TrpcContext["res"], user: undefined } as TrpcContext;
const adminCtx = { ...baseCtx, req: { protocol: "https", headers: { cookie: `anywheel_admin_session=${createAdminSession("+2250544894579").value}` } } as TrpcContext["req"] } as TrpcContext;

describe("admin transaction integration", () => {
  it("creates, lists, refreshes and persists a status with the full Wave phone", async () => {
    const caller = appRouter.createCaller(adminCtx);
    const created = await caller.demoAccount.createTransaction({ accountPhone: "+2250544894579", type: "deposit", phone: "+2250544894579", amount: 3000 });
    expect(created.phone).toBe("+2250544894579");
    expect((await caller.admin.transactions())[0]?.phone).toBe("+2250544894579");
    await caller.admin.updateStatus({ id: created.id!, status: "approved" });
    expect((await caller.admin.transactions())[0]?.status).toBe("approved");
  });

  it("refuses the admin list to a standard account without a signed session", async () => {
    await expect(appRouter.createCaller(baseCtx).admin.transactions()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });
});
