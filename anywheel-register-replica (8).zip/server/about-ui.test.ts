// @vitest-environment jsdom
import React from "react";
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import HistoryPanel from "../client/src/pages/HistoryPanel";
import { afterEach, describe, expect, it, vi } from "vitest";
afterEach(() => cleanup());

vi.mock("../client/src/_core/hooks/useAuth", () => ({
  useAuth: () => ({ user: { name: "Compte test" }, logout: vi.fn(), loading: false, error: null, isAuthenticated: true }),
}));

vi.mock("../client/src/lib/trpc", () => ({
  trpc: {
    demoAccount: {
      createTransaction: { useMutation: () => ({ mutateAsync: vi.fn() }) },
      portfolio: { useQuery: () => ({ data: { ledger: [{ id: 901, kind: "deposit", direction: "credit", amount: 3000, detail: "Dépôt confirmé", createdAt: new Date("2026-08-18T09:00:00Z"), phone: "+2250700000000", status: "approved", type: "deposit" }, { id: 902, kind: "withdrawal", direction: "debit", amount: 1500, detail: "Retrait demandé", createdAt: new Date("2026-08-18T11:00:00Z"), phone: "+2250700000000", status: "pending", type: "withdrawal" }] } }) },
      changeCode: { useMutation: () => ({ mutateAsync: vi.fn(), isPending: false }) },
      purchaseProduct: { useMutation: () => ({ mutate: vi.fn() }) },
    },
    admin: {
      me: { useQuery: () => ({ isLoading: false, data: undefined }) },
      transactions: { useQuery: () => ({ isLoading: false, data: [] }) },
      updateStatus: { useMutation: () => ({ isPending: false, mutate: vi.fn() }) },
    },
    useUtils: () => ({ admin: { transactions: { invalidate: vi.fn() } } }),
  },
}));

import { ActionSheet, AboutPanel, ChangeCodePanel, ContactPanel, Dashboard, HelpChat, MoiPanel, ProfilePanel, QuickAction } from "../client/src/pages/Home";
import HistoryPage from "../client/src/pages/HistoryPage";

describe("About panel", () => {
  it("shows the institutional Anywheel content and closes", () => {
    const onClose = vi.fn();
    render(React.createElement(AboutPanel, { onClose }));
    expect(screen.getByRole("heading", { name: "À propos de nous" })).toBeTruthy();
    expect(screen.getByText(/plateforme de vélos en libre-service basée à Singapour/i)).toBeTruthy();
    expect(screen.getByText(/programme de franchise d'Anywheel en Côte d'Ivoire/i)).toBeTruthy();
    screen.getByRole("button", { name: "Fermer" }).click();
    expect(onClose).toHaveBeenCalledTimes(1);
  });

  it("keeps transaction history and removes settings from the Moi menu", () => {
    const onHistory = vi.fn();
    const onAbout = vi.fn();
    render(React.createElement(ProfilePanel, { onAction: vi.fn(), onHelp: vi.fn(), onContact: vi.fn(), onHistory, onAbout, onChangeCode: vi.fn(), onLogout: vi.fn(async () => undefined), userLabel: "+225 07 00 00 00 00" }));
    screen.getByRole("button", { name: /Historique des transactions/i }).click();
    screen.getByRole("button", { name: /À propos de nous/i }).click();
    expect(onHistory).toHaveBeenCalledTimes(1);
    expect(onAbout).toHaveBeenCalledTimes(1);
    expect(screen.getByRole("button", { name: /Historique des transactions/i })).toBeTruthy();
    expect(screen.getByRole("button", { name: /À propos de nous/i })).toBeTruthy();
    expect(screen.getByRole("button", { name: /Modifier le code/i })).toBeTruthy();
    expect(screen.queryByText("Paramètres")).toBeNull();
    expect(screen.queryByText("Plus d’options")).toBeNull();
  });

  it("opens the real history and about panels from Moi", async () => {
    render(React.createElement(MoiPanel, { onAction: vi.fn(), onHelp: vi.fn(), onContact: vi.fn(), onChangeCode: vi.fn(), onLogout: vi.fn(async () => undefined), userLabel: "+225 07 00 00 00 00", entries: [] }));
    screen.getByRole("button", { name: /Historique des transactions/i }).click();
    await waitFor(() => expect(screen.getByRole("heading", { name: "Historique des transactions" })).toBeTruthy());
    screen.getByRole("button", { name: "Fermer" }).click();
    screen.getByRole("button", { name: /À propos de nous/i }).click();
    await waitFor(() => expect(screen.getByRole("heading", { name: "À propos de nous" })).toBeTruthy());
  });

  it("opens help from the quick action and the Moi menu", () => {
    const onQuickHelp = vi.fn();
    const onProfileHelp = vi.fn();
    render(React.createElement(QuickAction, { icon: React.createElement("span"), label: "Aide", onClick: onQuickHelp }));
    screen.getByRole("button", { name: "Aide" }).click();
    expect(onQuickHelp).toHaveBeenCalledTimes(1);
    cleanup();
    render(React.createElement(ProfilePanel, { onAction: vi.fn(), onHelp: onProfileHelp, onContact: vi.fn(), onHistory: vi.fn(), onAbout: vi.fn(), onChangeCode: vi.fn(), onLogout: vi.fn(async () => undefined), userLabel: "+225 07 00 00 00 00" }));
    screen.getByRole("button", { name: /Centre d'aide/i }).click();
    expect(onProfileHelp).toHaveBeenCalledTimes(1);
  });

  it("opens the chat from the real dashboard Aide button", async () => {
    localStorage.setItem("anywheel-announcement-seen", "1");
    render(React.createElement(Dashboard, { accountLabel: "2250700000000", onLocalLogout: vi.fn() }));
    screen.getByRole("button", { name: "Aide" }).click();
    await waitFor(() => expect(screen.getByRole("heading", { name: "Centre d’aide" })).toBeTruthy());
  });

  it("opens the chat from Moi Centre d’aide and answers a question", async () => {
    localStorage.setItem("anywheel-announcement-seen", "1");
    render(React.createElement(Dashboard, { accountLabel: "2250700000000", onLocalLogout: vi.fn() }));
    fireEvent.click(screen.getByRole("button", { name: "Moi" }));
    await waitFor(() => expect(screen.getByRole("button", { name: /Centre d'aide/i })).toBeTruthy());
    fireEvent.click(screen.getByRole("button", { name: /Centre d'aide/i }));
    await waitFor(() => expect(screen.getByRole("heading", { name: "Centre d’aide" })).toBeTruthy());
    const input = screen.getByPlaceholderText("Écrivez votre question…");
    fireEvent.change(input, { target: { value: "Comment faire un dépôt ?" } });
    fireEvent.keyDown(input, { key: "Enter" });
    await waitFor(() => expect(screen.getByText(/Les dépôts sont effectués avec Wave/i)).toBeTruthy());
  });

  it("answers a question inside the help chat", async () => {
    render(React.createElement(HelpChat, { onClose: vi.fn() }));
    const input = screen.getByPlaceholderText("Écrivez votre question…");
    fireEvent.change(input, { target: { value: "Comment faire un dépôt ?" } });
    fireEvent.keyDown(input, { key: "Enter" });
    await waitFor(() => expect(screen.getByText(/Les dépôts sont effectués avec Wave/i)).toBeTruthy());
  });

  it("opens contact from the real dashboard Moi tab", async () => {
    localStorage.setItem("anywheel-announcement-seen", "1");
    render(React.createElement(Dashboard, { accountLabel: "2250700000000", onLocalLogout: vi.fn() }));
    fireEvent.click(screen.getByRole("button", { name: "Moi" }));
    await waitFor(() => expect(screen.getByRole("button", { name: "Nous contacter" })).toBeTruthy());
    fireEvent.click(screen.getByRole("button", { name: "Nous contacter" }));
    await waitFor(() => expect(screen.getByRole("heading", { name: "Nous contacter" })).toBeTruthy());
    expect(screen.getByText("Chaque jour, de 9 h à 20 h")).toBeTruthy();
    expect(screen.getByRole("link", { name: /@Any_Chloe/i }).getAttribute("href")).toBe("https://t.me/Any_Chloe");
  });

  it("does not show history automatically on the dashboard home", async () => {
    localStorage.setItem("anywheel-announcement-seen", "1");
    render(React.createElement(Dashboard, { accountLabel: "2250700000000", onLocalLogout: vi.fn() }));
    await waitFor(() => expect(screen.getByRole("heading", { name: "Une nouvelle expérience commence." })).toBeTruthy());
    expect(screen.queryByRole("heading", { name: "Historique récent" })).toBeNull();
    expect(screen.queryByText("Dépôt confirmé")).toBeNull();
  });

  it("opens history from Moi with the connected account transaction details", async () => {
    localStorage.setItem("anywheel-announcement-seen", "1");
    render(React.createElement(Dashboard, { accountLabel: "2250700000000", onLocalLogout: vi.fn() }));
    fireEvent.click(screen.getByRole("button", { name: "Moi" }));
    await waitFor(() => expect(screen.getByRole("button", { name: /Historique des transactions/i })).toBeTruthy());
    fireEvent.click(screen.getByRole("button", { name: /Historique des transactions/i }));
    await waitFor(() => expect(screen.getByRole("heading", { name: "Historique des transactions" })).toBeTruthy());
    expect(screen.getByText("Dépôt confirmé")).toBeTruthy();
    expect(screen.getAllByText("+2250700000000").length).toBeGreaterThan(0);
    expect(screen.getAllByText(/18\/08\/2026/).length).toBeGreaterThan(0);
    expect(screen.getByText("Validé")).toBeTruthy();
    expect(screen.getByText("Dépôt").closest("tr")?.textContent).toContain("3 000");
  });

  it("opens the global history page from Moi", async () => {
    localStorage.setItem("anywheel-demo-account", "2250700000000");
    window.history.replaceState({}, "", "/");
    render(React.createElement(Dashboard, { accountLabel: "2250700000000", onLocalLogout: vi.fn() }));
    fireEvent.click(screen.getByRole("button", { name: "Moi" }));
    await waitFor(() => expect(screen.getByRole("button", { name: /Historique des transactions/i })).toBeTruthy());
    fireEvent.click(screen.getByRole("button", { name: /Historique des transactions/i }));
    await waitFor(() => expect(window.location.pathname).toBe("/history"));
  });

  it("opens the withdrawal history page from Retrait", async () => {
    window.history.replaceState({}, "", "/");
    render(React.createElement(ActionSheet, { action: "Retrait", hasPurchased: true, onClose: vi.fn(), onWithdrawalHistoryPage: () => window.history.pushState({}, "", "/withdrawal-history") }));
    fireEvent.click(screen.getByRole("button", { name: "Historique" }));
    await waitFor(() => expect(window.location.pathname).toBe("/withdrawal-history"));
  });

  it("renders the dedicated transaction history page for the connected account", () => {
    localStorage.setItem("anywheel-demo-account", "2250700000000");
    render(React.createElement(HistoryPage));
    expect(screen.getByRole("heading", { name: "Historique des transactions" })).toBeTruthy();
    expect(screen.getByText("Dépôt confirmé")).toBeTruthy();
  });

  it("renders the dedicated withdrawal history page with complete withdrawal details", () => {
    localStorage.setItem("anywheel-demo-account", "2250700000000");
    render(React.createElement(HistoryPage, { withdrawalsOnly: true }));
    expect(screen.getByRole("heading", { name: "Historique des retraits" })).toBeTruthy();
    expect(screen.queryByText("Dépôt confirmé")).toBeNull();
    expect(screen.getByText("Retrait demandé")).toBeTruthy();
    expect(screen.getAllByText("+2250700000000").length).toBeGreaterThan(0);
    expect(screen.getAllByText(/18\/08\/2026/).length).toBeGreaterThan(0);
    expect(screen.getByText("En attente")).toBeTruthy();
    expect(screen.getByText("Retrait").closest("tr")?.textContent).toContain("1 500");
  });

  it("returns from both dedicated history pages to the account", async () => {
    localStorage.setItem("anywheel-demo-account", "2250700000000");
    window.history.replaceState({}, "", "/history");
    const first = render(React.createElement(HistoryPage));
    fireEvent.click(screen.getByRole("button", { name: "Retour au compte" }));
    await waitFor(() => expect(window.location.pathname).toBe("/"));
    first.unmount();
    window.history.replaceState({}, "", "/withdrawal-history");
    render(React.createElement(HistoryPage, { withdrawalsOnly: true }));
    fireEvent.click(screen.getByRole("button", { name: "Retour au compte" }));
    await waitFor(() => expect(window.location.pathname).toBe("/"));
  });

  it("shows only withdrawal history from the Retrait action", () => {
    render(React.createElement(ActionSheet, { action: "Retrait", accountLabel: "2250700000000", onClose: vi.fn(), entries: [
      { id: 11, kind: "deposit", direction: "credit", amount: 3000, detail: "Dépôt confirmé", createdAt: new Date("2026-08-18T09:00:00Z"), phone: "+2250700000000", status: "approved", type: "deposit" },
      { id: 12, kind: "withdrawal", direction: "debit", amount: 1500, detail: "Retrait demandé", createdAt: new Date("2026-08-18T11:00:00Z"), phone: "+2250700000000", status: "pending", type: "withdrawal" },
    ] }));
    fireEvent.click(screen.getByRole("button", { name: "Historique" }));
    expect(screen.getByRole("heading", { name: "Historique des retraits" })).toBeTruthy();
    expect(screen.getByText("Retrait demandé")).toBeTruthy();
    expect(screen.queryByText("Dépôt confirmé")).toBeNull();
  });

  it("shows all transaction types provided for the connected account", () => {
    render(React.createElement(HistoryPanel, { onClose: vi.fn(), entries: [
      { id: 1, kind: "deposit", direction: "credit", amount: 3000, detail: "Dépôt confirmé", createdAt: new Date("2026-08-18T09:00:00Z"), phone: "+2250700000000", status: "approved", type: "deposit" },
      { id: 2, kind: "checkin", direction: "credit", amount: 35, detail: "Pointage quotidien", createdAt: new Date("2026-08-18T10:00:00Z") },
      { id: 3, kind: "withdrawal", direction: "debit", amount: 1500, detail: "Retrait demandé", createdAt: new Date("2026-08-18T11:00:00Z"), phone: "+2250700000000", status: "pending", type: "withdrawal" },
    ] }));
    expect(screen.getByText("Dépôt")).toBeTruthy();
    expect(screen.getByText("Pointage")).toBeTruthy();
    expect(screen.getByText("Retrait")).toBeTruthy();
    expect(screen.getByText("Dépôt").closest("tr")?.textContent).toContain("3 000");
  });

  it("shows a pending deposit in the account history with its status", () => {
    render(React.createElement(HistoryPanel, { onClose: vi.fn(), entries: [
      { id: 90, kind: "deposit", direction: "credit", amount: 5000, detail: "Dépôt Wave demandé", createdAt: new Date("2026-08-18T10:00:00Z"), phone: "+2250700000000", status: "pending", type: "deposit", balanceAfterCfa: 1500 },
    ] }));
    expect(screen.getByText("Dépôt Wave demandé")).toBeTruthy();
    expect(screen.getByText("En attente")).toBeTruthy();
    const depositRow = screen.getByText("Dépôt Wave demandé").closest("tr");
    expect(depositRow?.textContent).toContain("5 000 FCFA");
    expect(depositRow?.textContent).toContain("1 500 FCFA");
  });

  it("shows withdrawal gross amount, 20 percent fee, net amount and balance after", () => {
    render(React.createElement(HistoryPanel, { onClose: vi.fn(), title: "Historique des retraits", entries: [
      { id: 1, kind: "signup_bonus", direction: "credit", amount: 1500, detail: "Bonus d’inscription", createdAt: new Date("2026-08-18T08:00:00Z") },
      { id: 2, kind: "withdrawal", direction: "debit", amount: 1500, detail: "Retrait Wave demandé", createdAt: new Date("2026-08-18T11:00:00Z"), phone: "+2250700000000", status: "pending", type: "withdrawal", grossAmountCfa: 1500, feeCfa: 300, netAmountCfa: 1200, balanceAfterCfa: 0 },
    ] }));
    expect(screen.getByText("Montant brut")).toBeTruthy();
    expect(screen.getByText("Frais")).toBeTruthy();
    expect(screen.getByText("Net")).toBeTruthy();
    expect(screen.getByText("−300 FCFA")).toBeTruthy();
    const withdrawalRow = screen.getByText("Retrait Wave demandé").closest("tr");
    expect(withdrawalRow?.textContent).toContain("1 200 FCFA");
    expect(withdrawalRow?.textContent).toContain("0 FCFA");
  });

  it("shows the contact panel with Telegram links and availability", () => {
    render(React.createElement(ContactPanel, { onClose: vi.fn() }));
    expect(screen.getByRole("heading", { name: "Nous contacter" })).toBeTruthy();
    expect(screen.getByText("Chaque jour, de 9 h à 20 h")).toBeTruthy();
    expect(screen.getByRole("link", { name: /@Any_Chloe/i }).getAttribute("href")).toBe("https://t.me/Any_Chloe");
    expect(screen.getByRole("link", { name: /@AnywheelA2/i }).getAttribute("href")).toBe("https://t.me/AnywheelA2");
  });

  it("shows the code change form", () => {
    render(React.createElement(ChangeCodePanel, { accountPhone: "+2250700000000", onClose: vi.fn(), onSuccess: vi.fn() }));
    expect(screen.getByRole("heading", { name: "Modifier le code" })).toBeTruthy();
    expect(screen.getByLabelText("Code actuel")).toBeTruthy();
    expect(screen.getByLabelText("Nouveau code")).toBeTruthy();
    expect(screen.getByLabelText("Confirmer le nouveau code")).toBeTruthy();
  });
});
