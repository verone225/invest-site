import { and, desc, eq, gte, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { DemoAccount, DemoLedgerEntry, DemoPurchase, DemoTransaction, InsertDemoAccount, InsertDemoTransaction, InsertUser, demoAccounts, demoLedger, demoPurchases, demoTransactions, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getDemoAccountByPhone(phone: string): Promise<DemoAccount | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(demoAccounts).where(eq(demoAccounts.phone, phone)).limit(1);
  return result[0];
}

export async function getDemoAccountByInviteCode(inviteCode: string): Promise<DemoAccount | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(demoAccounts).where(eq(demoAccounts.inviteCode, inviteCode)).limit(1);
  return result[0];
}

export async function updateDemoAccountCode(phone: string, codeHash: string): Promise<DemoAccount | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  await db.update(demoAccounts).set({ codeHash }).where(eq(demoAccounts.phone, phone));
  return getDemoAccountByPhone(phone);
}

export async function hasCompletedPurchase(accountPhone: string) {
  const db = await getDb();
  if (!db) return false;
  const rows = await db.select().from(demoPurchases).where(eq(demoPurchases.accountPhone, accountPhone)).limit(1);
  return Boolean(rows[0]);
}

export async function listDemoPurchases(accountPhone: string): Promise<DemoPurchase[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(demoPurchases).where(eq(demoPurchases.accountPhone, accountPhone)).orderBy(desc(demoPurchases.createdAt));
}

export async function createDemoPurchase(input: { accountPhone: string; productName: string; amount: number }): Promise<DemoPurchase | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  if (!Number.isInteger(input.amount) || input.amount <= 0) throw new Error("Le prix du produit est invalide.");
  const debit = await db.update(demoAccounts)
    .set({ balanceCfa: sql`${demoAccounts.balanceCfa} - ${input.amount}`, updatedAt: new Date() })
    .where(and(eq(demoAccounts.phone, input.accountPhone), gte(demoAccounts.balanceCfa, input.amount)));
  const affectedRows = Number((debit as any)[0]?.affectedRows ?? (debit as any).affectedRows ?? 0);
  if (affectedRows < 1) throw new Error("Solde insuffisant pour acheter ce produit.");
  try {
    const result = await db.insert(demoPurchases).values({ ...input, status: "completed" });
    const purchaseId = Number((result as any)[0]?.insertId ?? 0);
    await db.insert(demoLedger).values({ accountPhone: input.accountPhone, kind: "purchase", direction: "debit", amount: input.amount, detail: `Achat du produit ${input.productName}` });
    const buyer = await getDemoAccountByPhone(input.accountPhone);
    if (buyer?.referrerPhone) {
      const referralCommission = Math.round(input.amount * 0.39);
      await creditReferralRevenue(buyer.referrerPhone, referralCommission, `Commission de parrainage sur l’achat de ${input.productName}`);
    }
    const rows = purchaseId
      ? await db.select().from(demoPurchases).where(eq(demoPurchases.id, purchaseId)).limit(1)
      : await db.select().from(demoPurchases).where(eq(demoPurchases.accountPhone, input.accountPhone)).orderBy(desc(demoPurchases.createdAt)).limit(1);
    return rows[0];
  } catch (error) {
    await db.update(demoAccounts).set({ balanceCfa: sql`${demoAccounts.balanceCfa} + ${input.amount}`, updatedAt: new Date() }).where(eq(demoAccounts.phone, input.accountPhone));
    throw error;
  }
}

export async function createDemoTransaction(input: InsertDemoTransaction): Promise<DemoTransaction | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.insert(demoTransactions).values(input);
  const id = Number(result[0].insertId);
  const rows = await db.select().from(demoTransactions).where(eq(demoTransactions.id, id)).limit(1);
  return rows[0];
}

export async function listDemoTransactions(): Promise<DemoTransaction[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(demoTransactions).orderBy(desc(demoTransactions.createdAt));
}

export async function updateDemoTransactionStatus(id: number, status: "pending" | "approved" | "rejected"): Promise<DemoTransaction | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const before = (await db.select().from(demoTransactions).where(eq(demoTransactions.id, id)).limit(1))[0];
  if (!before) return undefined;
  await db.update(demoTransactions).set({ status, updatedAt: new Date() }).where(eq(demoTransactions.id, id));
  if (before.type === "deposit" && before.status !== "approved" && status === "approved") {
    const duplicate = await db.select().from(demoLedger).where(eq(demoLedger.transactionId, id)).limit(1);
    if (!duplicate[0]) {
      await db.insert(demoLedger).values({ accountPhone: before.accountPhone, kind: "deposit", direction: "credit", amount: before.amount, transactionId: id, detail: "Dépôt Wave approuvé par l’administrateur" });
      await db.update(demoAccounts).set({ balanceCfa: sql`${demoAccounts.balanceCfa} + ${before.amount}`, updatedAt: new Date() }).where(eq(demoAccounts.phone, before.accountPhone));
    }
  }
  if (before.type === "withdrawal" && before.status !== "approved" && status === "approved") {
    const duplicate = await db.select().from(demoLedger).where(eq(demoLedger.transactionId, id)).limit(1);
    if (!duplicate[0]) {
      await db.insert(demoLedger).values({ accountPhone: before.accountPhone, kind: "withdrawal", direction: "debit", amount: before.amount, transactionId: id, detail: "Retrait Wave approuvé par l’administrateur" });
      await db.update(demoAccounts).set({ balanceCfa: sql`${demoAccounts.balanceCfa} - ${before.amount}`, updatedAt: new Date() }).where(eq(demoAccounts.phone, before.accountPhone));
    }
  }
  const rows = await db.select().from(demoTransactions).where(eq(demoTransactions.id, id)).limit(1);
  return rows[0];
}

export async function listLedgerByAccount(accountPhone: string) {
  const db = await getDb();
  if (!db) return [];
  const ledgerEntries = await db.select().from(demoLedger).where(eq(demoLedger.accountPhone, accountPhone)).orderBy(desc(demoLedger.createdAt));
  const transactions = await db.select().from(demoTransactions).where(eq(demoTransactions.accountPhone, accountPhone)).orderBy(desc(demoTransactions.createdAt));
  const ledgerTransactionIds = new Set(ledgerEntries.filter(entry => entry.transactionId).map(entry => entry.transactionId));
  const pendingTransactionEntries = transactions.filter(transaction => !ledgerTransactionIds.has(transaction.id)).map(transaction => ({
    id: -transaction.id,
    accountPhone: transaction.accountPhone,
    kind: transaction.type,
    direction: transaction.type === "deposit" ? "credit" as const : "debit" as const,
    amount: transaction.amount,
    transactionId: transaction.id,
    detail: transaction.type === "deposit" ? "Dépôt Wave demandé" : "Retrait Wave demandé",
    createdAt: transaction.createdAt,
    phone: transaction.phone,
    status: transaction.status,
    type: transaction.type,
    grossAmountCfa: transaction.type === "withdrawal" ? transaction.amount : undefined,
    feeCfa: transaction.type === "withdrawal" ? Math.round(transaction.amount * 0.2) : 0,
    netAmountCfa: transaction.type === "withdrawal" ? transaction.amount - Math.round(transaction.amount * 0.2) : undefined,
    affectsBalance: false,
  }));
  const entries: Array<any> = [...ledgerEntries, ...pendingTransactionEntries];
  const enriched = await Promise.all(entries.map(async entry => {
    if (!entry.transactionId || entry.id < 0) return { ...entry, phone: entry.phone, status: entry.status, type: entry.type, grossAmountCfa: entry.grossAmountCfa, feeCfa: entry.feeCfa ?? 0, netAmountCfa: entry.netAmountCfa, affectsBalance: entry.affectsBalance ?? true };
    const transaction = (await db.select().from(demoTransactions).where(eq(demoTransactions.id, entry.transactionId)).limit(1))[0];
    const isWithdrawal = transaction?.type === "withdrawal";
    const grossAmountCfa = isWithdrawal ? transaction.amount : undefined;
    const feeCfa = isWithdrawal ? Math.round(transaction.amount * 0.2) : 0;
    const netAmountCfa = isWithdrawal ? transaction.amount - feeCfa : undefined;
    return { ...entry, phone: transaction?.phone, status: transaction?.status, type: transaction?.type, grossAmountCfa, feeCfa, netAmountCfa, affectsBalance: true };
  }));
  let balanceAfterCfa = 0;
  const chronological = [...enriched].sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime() || a.id - b.id);
  const balanceById = new Map<number, number>();
  for (const entry of chronological) {
    if (entry.affectsBalance !== false) balanceAfterCfa += entry.direction === "debit" ? -entry.amount : entry.amount;
    balanceById.set(entry.id, balanceAfterCfa);
  }
  return enriched.map(entry => ({ ...entry, balanceAfterCfa: balanceById.get(entry.id) ?? 0 }));
}

export async function getPortfolioSummary(accountPhone: string) {
  const account = await getDemoAccountByPhone(accountPhone);
  const ledger = await listLedgerByAccount(accountPhone);
  const totalRevenueCfa = ledger.filter(entry => entry.direction === "credit" && ["revenue", "referral", "checkin", "signup_bonus"].includes(entry.kind)).reduce((sum, entry) => sum + entry.amount, 0);
  const referralRevenueCfa = ledger.filter(entry => entry.kind === "referral" && entry.direction === "credit").reduce((sum, entry) => sum + entry.amount, 0);
  return { account, ledger, totalRevenueCfa, referralRevenueCfa };
}

export async function creditReferralRevenue(accountPhone: string, amount: number, detail: string) {
  const db = await getDb();
  if (!db) return undefined;
  await db.insert(demoLedger).values({ accountPhone, kind: "referral", direction: "credit", amount, detail });
  await db.update(demoAccounts).set({ balanceCfa: sql`${demoAccounts.balanceCfa} + ${amount}`, referralRevenueCfa: sql`${demoAccounts.referralRevenueCfa} + ${amount}`, cumulativeRevenueCfa: sql`${demoAccounts.cumulativeRevenueCfa} + ${amount}`, updatedAt: new Date() }).where(eq(demoAccounts.phone, accountPhone));
  return getDemoAccountByPhone(accountPhone);
}

export async function createDemoAccount(input: InsertDemoAccount): Promise<DemoAccount | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  await db.insert(demoAccounts).values(input);
  await db.insert(demoLedger).values({ accountPhone: input.phone, kind: "signup_bonus", direction: "credit", amount: 1500, detail: "Bonus d’inscription" });
  return getDemoAccountByPhone(input.phone);
}
