CREATE TABLE `demo_transactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`type` enum('deposit','withdrawal') NOT NULL,
	`phone` varchar(20) NOT NULL,
	`amount` int NOT NULL,
	`status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `demo_transactions_id` PRIMARY KEY(`id`)
);
