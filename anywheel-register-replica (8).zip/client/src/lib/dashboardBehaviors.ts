export const actionMessages: Record<string, string> = {
  Recharge: "Choisissez un montant et soumettez votre demande de dépôt.",
  Retrait: "Minimum 1 500 FCFA, frais de 20 %, retraits disponibles à tout moment et traitement sous 4 à 24 heures. Un produit acheté est requis pour activer le retrait.",
  Aide: "Le centre d’aide vous accompagne pour votre compte et vos produits.",
  Pointage: "Validez votre présence quotidienne pour actualiser vos avantages.",
};

export const announcementStartsOpen = true;

export function dismissAnnouncement() {
  return false;
}

export function getActionMessage(action: string) {
  return actionMessages[action] || "Cette fonctionnalité est disponible depuis votre espace personnel.";
}
