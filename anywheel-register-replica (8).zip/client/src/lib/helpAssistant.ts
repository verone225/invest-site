export type HelpTopic = "registration" | "deposit" | "withdrawal" | "product" | "checkin" | "referral" | "history" | "code" | "about" | "general";

const responses: Record<HelpTopic, string> = {
  registration: "Pour vous inscrire, choisissez « S’inscrire », saisissez un numéro ivoirien au format +225, un code de connexion à 6 chiffres, confirmez ce code et indiquez votre code d’invitation. Aucun OTP n’est demandé.",
  deposit: "Les dépôts sont effectués avec Wave. Dans « Recharge », choisissez uniquement 3 000, 10 000 ou 25 000 FCFA, saisissez le numéro Wave utilisé puis envoyez la demande. Son statut est suivi dans votre espace.",
  withdrawal: "Pour demander un retrait, ouvrez « Retrait », saisissez le numéro Wave de destination et le montant. Le minimum est de 1 500 FCFA, les frais sont de 20 % du montant retiré, et les retraits sont disponibles à tout moment avec un traitement sous 4 à 24 heures. Vous devez avoir acheté au moins un produit pour activer le retrait.",
  product: "La rubrique « Produit » présente les offres disponibles avec leur prix, leur durée et les revenus indiqués. Sélectionnez une offre puis confirmez l’achat pour l’enregistrer sur votre compte.",
  checkin: "Le bouton « Pointage » ajoute 50 FCFA à votre solde une seule fois par jour. Le bonus est conservé et pris en compte dans le solde affiché.",
  referral: "Dans « Équipe », vous pouvez partager votre code d’invitation et suivre les informations de votre réseau ainsi que les récompenses de parrainage créditées sur votre compte.",
  history: "Depuis « Moi », ouvrez « Historique des transactions » pour consulter les opérations enregistrées, leurs montants, leurs dates et leurs statuts.",
  code: "Depuis « Moi », choisissez « Modifier le code ». Saisissez votre code actuel, un nouveau code de 6 chiffres et confirmez-le. L’ancien code doit être correct et le nouveau doit être différent.",
  about: "Anywheel est une plateforme de vélos en libre-service basée à Singapour. Elle s’appuie sur la mobilité verte, l’IoT et une application mobile pour faciliter les trajets urbains, la géolocalisation, le déverrouillage et la gestion des vélos.",
  general: "Je peux vous renseigner sur l’inscription, les produits, le dépôt Wave, le retrait, le pointage de 50 FCFA, le parrainage, l’historique, la modification du code ou la présentation d’Anywheel."
};

const topicKeywords: Array<[HelpTopic, string[]]> = [
  ["registration", ["inscri", "compte", "inscrire", "otp", "numero", "numéro"]],
  ["deposit", ["depot", "dépôt", "recharge", "wave", "verser"]],
  ["withdrawal", ["retrait", "retirer", "sortir", "minimum"]],
  ["product", ["produit", "pack", "acheter", "achat", "prix"]],
  ["checkin", ["pointage", "pointer", "50", "35", "bonus", "quotidien"]],
  ["referral", ["parrain", "invitation", "ami", "commission", "equipe", "équipe"]],
  ["history", ["historique", "transaction", "opération", "statut"]],
  ["code", ["modifier le code", "changer le code", "code de connexion", "ancien code"]],
  ["about", ["à propos", "propos", "singapour", "vélo", "mobilité"]]
];

export function answerHelpQuestion(question: string): { topic: HelpTopic; answer: string } {
  const normalized = question.toLocaleLowerCase("fr-FR");
  for (const [topic, keywords] of topicKeywords) {
    if (keywords.some(keyword => normalized.includes(keyword))) return { topic, answer: responses[topic] };
  }
  return { topic: "general", answer: responses.general };
}
