import { describe, expect, it } from "vitest";
import { normalizeIvorianPhone, validateAccessForm } from "./phoneAuth";

describe("phone access without OTP", () => {
  it("normalizes spaces in an Ivorian phone number", () => {
    expect(normalizeIvorianPhone("+225 07 00 00 00 00")).toBe("+2250700000000");
  });

  it("accepts a valid login", () => {
    expect(validateAccessForm({ phone: "+225 07 00 00 00 00", code: "123456", mode: "login" })).toBeNull();
  });

  it("rejects invalid phone and code values", () => {
    expect(validateAccessForm({ phone: "+33 06 00 00 00 00", code: "123456", mode: "login" })).toMatch(/numéro ivoirien/);
    expect(validateAccessForm({ phone: "+225 07 00 00 00 00", code: "12345", mode: "login" })).toMatch(/6 chiffres/);
  });

  it("allows registration with or without an invitation code", () => {
    expect(validateAccessForm({ phone: "+225 05 00 00 00 00", code: "123456", invite: "", mode: "register" })).toBeNull();
    expect(validateAccessForm({ phone: "+225 05 00 00 00 00", code: "123456", invite: "d9s3p7", mode: "register" })).toBeNull();
  });
});
