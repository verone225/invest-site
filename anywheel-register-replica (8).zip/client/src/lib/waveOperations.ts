export const wavePackAmounts = [3000, 10000, 25000] as const;
export const waveWithdrawalAmounts = [1500, 3000, 10000] as const;
export const WITHDRAWAL_FEE_RATE = 0.2;

export function calculateWithdrawalFee(amount: number) {
  return Math.round(amount * WITHDRAWAL_FEE_RATE);
}

export function calculateWithdrawalNet(amount: number) {
  return amount - calculateWithdrawalFee(amount);
}

export function isValidWavePhone(phone: string) {
  return /^\+225(0[157])[0-9]{8}$/.test(phone.replace(/\s/g, ""));
}

export function isValidWaveWithdrawalAmount(amount: number) {
  return waveWithdrawalAmounts.includes(amount as (typeof waveWithdrawalAmounts)[number]);
}

export function validateWaveWithdrawal(phone: string, amount: number) {
  if (!isValidWavePhone(phone)) return "Entrez un numéro Wave ivoirien valide au format +225.";
  if (!Number.isInteger(amount) || amount <= 0) return "Saisissez un montant de retrait supérieur à 0 FCFA.";
  if (amount < 1500) return "Le montant de retrait doit être supérieur ou égal à 1 500 FCFA.";
  return null;
}
