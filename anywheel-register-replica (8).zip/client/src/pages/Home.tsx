/*
 * Style reminder: tableau de bord mobile inspiré des captures fournies — blanc lumineux,
 * vert mobilité #11b83f, cartes superposées, navigation fixe basse et interactions locales.
 * Les informations commerciales sont présentées avec une hiérarchie claire et un ton institutionnel.
 */
import React, { useEffect, useMemo, useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { normalizeIvorianPhone, validateAccessForm } from "@/lib/phoneAuth";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { AIChatBox, type Message } from "@/components/AIChatBox";
import HistoryPanel from "@/pages/HistoryPanel";
import { announcementStartsOpen, dismissAnnouncement, getActionMessage } from "@/lib/dashboardBehaviors";
import { answerHelpQuestion } from "@/lib/helpAssistant";
import { calculateWithdrawalFee, calculateWithdrawalNet, isValidWavePhone, validateWaveWithdrawal } from "@/lib/waveOperations";
import { claimDailyCheckin } from "@/lib/dailyCheckin";
import { addDemoTransaction, getDemoTransactions, maskWavePhone, updateDemoTransactionStatus, type DemoTransaction, type TransactionStatus } from "@/lib/demoTransactions";
import { ADMIN_REFETCH_INTERVAL_MS, shouldRefreshAfterAdminMutation } from "@/lib/adminRefresh";
import {
  Bell, Bike, CalendarDays, ChevronRight, CircleHelp, Copy, DollarSign, Home as HomeIcon,
  Menu, MessageCircle, MoreHorizontal, RefreshCw, ShoppingBag, UserRound, UsersRound, WalletCards, X,
} from "lucide-react";

const promoText = "Anywheel Côte d'Ivoire\n\nOffre de lancement\n• Packs disponibles à partir de 3 000 FCFA\n• Solde initial : 1 500 FCFA\n• Avantage de connexion quotidienne : 50 FCFA\n• Programme de parrainage : commission annoncée jusqu'à 39 %\n• Les produits et leurs conditions sont présentés dans la rubrique Produit.\n• Retrait minimum : 1 500 FCFA, avec 20 % de frais.\n• Retraits disponibles à tout moment, traitement sous 4 à 24 heures.\n• Un produit acheté est requis pour activer le retrait.\n• Les demandes sont enregistrées dans votre espace et traitées selon les règles du service.";

const WAVE_PAYMENT_LINK = "https://pay.wave.com/m/M_ci_FRXXXdrF0K8S/c/ci/";

export function getWaveDepositUrl(amount: number) {
  return `${WAVE_PAYMENT_LINK}?amount=${encodeURIComponent(amount)}`;
}

const products = [
  { name: "VIP1 Anywheel Bike", price: "3 000", daily: "750", total: "135 000" },
  { name: "VIP2 Anywheel Bike", price: "5 000", daily: "1 250", total: "225 000" },
  { name: "VIP3 Anywheel Bike", price: "10 000", daily: "2 550", total: "459 000" },
  { name: "VIP4 Anywheel Bike", price: "25 000", daily: "6 500", total: "1 170 000" },
];

type Tab = "home" | "products" | "team" | "me";

export function Dashboard({ accountLabel, onLocalLogout }: { accountLabel: string; onLocalLogout: () => void }) {
  const [, setLocation] = useLocation();
  const { user, logout } = useAuth();
  const utils = trpc.useUtils();
  const portfolioQuery = trpc.demoAccount.portfolio.useQuery({ phone: `+${accountLabel}` }, { enabled: accountLabel.startsWith("225") });
  const purchaseProduct = trpc.demoAccount.purchaseProduct.useMutation({ onSuccess: async () => { await utils.demoAccount.portfolio.invalidate({ phone: `+${accountLabel}` }); notify("Produit acheté avec le solde du compte."); }, onError: (error) => notify(error.message || "Solde insuffisant pour acheter ce produit.") });
  const [dailyBonus, setDailyBonus] = useState(() => Number(localStorage.getItem("anywheel-daily-bonus") || "0"));

  const [tab, setTab] = useState<Tab>("home");
  const [notice, setNotice] = useState("");
  const [activeAction, setActiveAction] = useState<string | null>(null);
  const [showPromo, setShowPromo] = useState(true);
  const [showAnnouncement, setShowAnnouncement] = useState(announcementStartsOpen);

  const [showChangeCode, setShowChangeCode] = useState(false);
  const [showHelpChat, setShowHelpChat] = useState(false);
  const [showContact, setShowContact] = useState(false);

  const tabLabel = useMemo(() => ({ home: "Accueil", products: "Produit", team: "Équipe", me: "Moi" }[tab]), [tab]);

  function notify(message: string) {
    setNotice(message);
    window.setTimeout(() => setNotice(""), 2600);
  }

  const inviteCode = portfolioQuery.data?.inviteCode ?? "";

  function copyInvite() {
    const link = `${window.location.origin}/reg?code=${encodeURIComponent(inviteCode)}`;
    navigator.clipboard?.writeText(link);
    notify("Lien d’invitation copié.");
  }

  function handleAction(action: string) {
    if (action === "Aide" || action === "Centre d'aide") { setActiveAction(null); setShowHelpChat(true); return; }
    setActiveAction(action);
    notify(`${action} : demande disponible.`);
  }

  return (
    <main className="dashboard-shell">
      <div className="dashboard-frame">
        <header className="dashboard-hero">
          <div className="dashboard-hero-visual" aria-hidden="true"><Bike size={72} strokeWidth={1.2} /></div>
          <div className="dashboard-hero-shade" />
          <div className="dashboard-topline">
            <div className="brand-lockup"><span className="brand-dot" /> anywheel</div>
            <div className="user-chip">{user?.name || user?.email || "Compte"}</div>
            <button className="icon-button light" onClick={() => notify("Aucune nouvelle notification.")} aria-label="Notifications"><Bell size={20} /></button>
          </div>
          <div className="hero-copy">
            <p className="eyebrow">Anywheel Côte d'Ivoire</p>
            <h1>Une nouvelle expérience commence.</h1>
            <p>Mobilité, récompenses et communauté réunies dans un même espace.</p>
          </div>
        </header>

        <section className="quick-actions" aria-label="Actions rapides">
          <QuickAction icon={<DollarSign />} label="Recharge" onClick={() => handleAction("Recharge")} />
          <QuickAction icon={<WalletCards />} label="Retrait" onClick={() => handleAction("Retrait")} />
          <QuickAction icon={<MessageCircle />} label="Aide" onClick={() => setShowHelpChat(true)} />
          <QuickAction icon={<CalendarDays />} label="Pointage" onClick={() => handleAction("Pointage")} />
        </section>

        {showPromo && (
          <section className="promo-banner" aria-label="Avertissement sur les informations promotionnelles">
            <div><strong>Informations promotionnelles</strong><span>Consultez les conditions des produits avant toute demande.</span></div>
            <button onClick={() => setShowPromo(false)} aria-label="Fermer l’avertissement"><X size={16} /></button>
          </section>
        )}

        <div className="dashboard-content">
          {tab === "home" && <HomePanel onNavigate={setTab} onCopy={copyInvite} inviteCode={inviteCode} balanceCfa={(portfolioQuery.data?.balanceCfa ?? 1500) + dailyBonus} cumulativeRevenueCfa={(portfolioQuery.data?.cumulativeRevenueCfa ?? 1500) + dailyBonus} referralRevenueCfa={portfolioQuery.data?.referralRevenueCfa ?? 0} />}
          {tab === "products" && <ProductsPanel onBuy={(product) => purchaseProduct.mutate({ accountPhone: `+${accountLabel}`, productName: product.name, amount: Number(product.price.replace(/\s/g, "")) })} onMyProducts={() => setLocation("/my-products")} />} 
          {tab === "team" && <TeamPanel onCopy={copyInvite} referralRevenueCfa={portfolioQuery.data?.referralRevenueCfa ?? 0} />}
          {tab === "me" && <MoiPanel onAction={handleAction} onHistoryPage={() => setLocation("/history")} onProductsPage={() => setLocation("/my-products")} onHelp={() => setShowHelpChat(true)} onContact={() => setShowContact(true)} onChangeCode={() => setShowChangeCode(true)} onLogout={async () => { await logout(); onLocalLogout(); }} userLabel={user?.name || user?.email || accountLabel} entries={portfolioQuery.data?.ledger ?? []} />}
        </div>

        <nav className="bottom-nav" aria-label="Navigation principale">
          <NavItem active={tab === "home"} icon={<HomeIcon />} label="Accueil" onClick={() => setTab("home")} />
          <NavItem active={tab === "products"} icon={<Bike />} label="Produit" onClick={() => setTab("products")} />
          <NavItem active={tab === "team"} icon={<UsersRound />} label="Équipe" onClick={() => setTab("team")} />
          <NavItem active={tab === "me"} icon={<UserRound />} label="Moi" onClick={() => setTab("me")} />
        </nav>

        {notice && <div className="toast" role="status">{notice}</div>}
        {activeAction && <ActionSheet action={activeAction} accountLabel={accountLabel} hasPurchased={portfolioQuery.data?.hasPurchased ?? false} entries={portfolioQuery.data?.ledger ?? []} onWithdrawalHistoryPage={() => setLocation("/withdrawal-history")} onClose={() => setActiveAction(null)} onCheckin={() => { const result = claimDailyCheckin(localStorage); setDailyBonus(result.bonusTotal); return result; }} onTransaction={() => notify("Demande enregistrée dans la file administrateur.")} />}

        {showChangeCode && <ChangeCodePanel accountPhone={`+${accountLabel}`} onClose={() => setShowChangeCode(false)} onSuccess={() => { setShowChangeCode(false); notify("Votre code a été modifié avec succès."); }} />}
        {showHelpChat && <HelpChat onClose={() => setShowHelpChat(false)} />}
        {showContact && <ContactPanel onClose={() => setShowContact(false)} />}
        {showAnnouncement && <AnnouncementModal onClose={() => setShowAnnouncement(dismissAnnouncement())} />}
      </div>
    </main>
  );
}

export default function Home() {
  const { loading, isAuthenticated } = useAuth();
  const [localAccount, setLocalAccount] = useState(() => localStorage.getItem("anywheel-demo-account") || "");
  const adminMe = trpc.admin.me.useQuery(undefined, { enabled: localAccount.startsWith("admin:") });
  if (loading || (localAccount.startsWith("admin:") && adminMe.isLoading)) return <AuthLoading />;
  const logoutLocal = () => { localStorage.removeItem("anywheel-demo-account"); localStorage.removeItem("anywheel-admin"); setLocalAccount(""); };
  if (localAccount.startsWith("admin:") && adminMe.data?.authorized) return <AdminDashboard onLogout={logoutLocal} />;
  if (!isAuthenticated && (!localAccount || localAccount.startsWith("admin:"))) return <AuthGate onSuccess={setLocalAccount} />;
  return <Dashboard accountLabel={localAccount || "Compte connecté"} onLocalLogout={logoutLocal} />;
}

export function AboutPanel({ onClose }: { onClose: () => void }) {
  return <div className="about-backdrop" role="dialog" aria-modal="true" aria-labelledby="about-title"><section className="about-panel"><div className="about-header"><div><p className="eyebrow">Anywheel Côte d'Ivoire</p><h2 id="about-title">À propos de nous</h2></div><button className="sheet-close" onClick={onClose}>Fermer</button></div><div className="about-content"><p>Anywheel est une plateforme de vélos en libre-service basée à Singapour, qui propose des services de transport de courte distance pratiques et efficaces aux citadins grâce à la technologie et aux concepts de mobilité verte. L'entreprise utilise l'Internet des objets (IoT) et une application mobile pour une géolocalisation précise des vélos, le déverrouillage par QR code, la facturation automatique et une gestion en temps réel, permettant aux utilisateurs de se déplacer facilement, n'importe où et n'importe quand.</p><p>Anywheel est principalement destiné aux trajets domicile-travail, aux déplacements universitaires et aux transports communautaires de courte distance. Les utilisateurs peuvent rapidement trouver des vélos à proximité et les louer via une application mobile. La plateforme utilise des cadenas intelligents et un système de gestion des données pour optimiser la gestion des véhicules tout en garantissant sécurité et confort d'utilisation.</p><p>Acteur majeur de la micromobilité urbaine, Anywheel promeut activement les solutions écologiques et respectueuses de l'environnement, réduisant l'utilisation de la voiture grâce à un modèle de partage afin de diminuer les émissions de carbone et de fluidifier la circulation. À l'avenir, Anywheel continuera d'étendre sa zone de service, d'optimiser sa technologie et ses systèmes opérationnels, et de proposer à un plus grand nombre de citadins des solutions de transport intelligentes, écologiques et pratiques, contribuant ainsi au développement des transports en ville intelligente.</p><p>Le programme de franchise d'Anywheel en Côte d'Ivoire est officiellement lancé et nous invitons chaleureusement les partenaires locaux à nous rejoindre. Participez au développement de la plateforme, partagez les dividendes des revenus et bénéficiez d'un partage des bénéfices.</p></div></section></div>;
}

export function ContactPanel({ onClose }: { onClose: () => void }) {
  const contacts = ["https://t.me/Any_Chloe", "https://t.me/AnywheelA2"];
  return <div className="about-backdrop" role="dialog" aria-modal="true" aria-labelledby="contact-title"><section className="about-panel contact-panel"><div className="about-header"><div><p className="eyebrow">Assistance Anywheel</p><h2 id="contact-title">Nous contacter</h2></div><button className="sheet-close" onClick={onClose}>Fermer</button></div><div className="contact-content"><div className="contact-hours"><strong>Disponibilité</strong><span>Chaque jour, de 9 h à 20 h</span></div><p>Notre équipe est disponible sur Telegram pour répondre à vos questions.</p><div className="contact-links">{contacts.map((link) => <a key={link} href={link} target="_blank" rel="noreferrer" className="contact-link"><MessageCircle size={20} /><span>{link.replace("https://t.me/", "@")} </span><ChevronRight size={17} /></a>)}</div></div></section></div>;
}

export function HelpChat({ onClose }: { onClose: () => void }) {
  const [messages, setMessages] = useState<Message[]>([{ role: "assistant", content: "Bonjour, je suis l’assistant Anywheel. Posez-moi une question sur l’inscription, les produits, le dépôt, le retrait, le pointage, le parrainage, l’historique ou votre code." }]);
  function sendMessage(content: string) {
    const response = answerHelpQuestion(content);
    setMessages(current => [...current, { role: "user", content }, { role: "assistant", content: response.answer }]);
  }
  return <div className="help-backdrop" role="dialog" aria-modal="true" aria-labelledby="help-title"><section className="help-panel"><div className="help-header"><div><p className="eyebrow">Assistance Anywheel</p><h2 id="help-title">Centre d’aide</h2></div><button className="sheet-close" onClick={onClose}>Fermer</button></div><AIChatBox messages={messages} onSendMessage={sendMessage} height="min(68vh,560px)" placeholder="Écrivez votre question…" emptyStateMessage="Posez votre question à l’assistant Anywheel" suggestedPrompts={["Comment faire un dépôt ?", "Comment modifier mon code ?", "Comment demander un retrait ?"]} /></section></div>;
}

export function MoiPanel({ onAction, onHelp, onContact, onHistoryPage, onProductsPage, onChangeCode, onLogout, userLabel, entries }: { onAction: (action: string) => void; onHelp: () => void; onContact: () => void; onHistoryPage?: () => void; onProductsPage?: () => void; onChangeCode: () => void; onLogout: () => Promise<void>; userLabel: string; entries: Array<{ id: number; kind: string; direction: string; amount: number; detail: string; createdAt: Date; phone?: string; status?: string; type?: string }> }) {
  const [showHistory, setShowHistory] = useState(false);
  const [showAbout, setShowAbout] = useState(false);
  return <><ProfilePanel onAction={onAction} onHelp={onHelp} onContact={onContact} onHistory={() => onHistoryPage?.() ?? setShowHistory(true)} onProductsPage={() => onProductsPage?.()} onAbout={() => setShowAbout(true)} onChangeCode={onChangeCode} onLogout={onLogout} userLabel={userLabel} />{showHistory && <HistoryPanel entries={entries} onClose={() => setShowHistory(false)} />}{showAbout && <AboutPanel onClose={() => setShowAbout(false)} />}</>;
}

export function ChangeCodePanel({ accountPhone, onClose, onSuccess }: { accountPhone: string; onClose: () => void; onSuccess: () => void }) {
  const [currentCode, setCurrentCode] = useState("");
  const [newCode, setNewCode] = useState("");
  const [confirmCode, setConfirmCode] = useState("");
  const [error, setError] = useState("");
  const changeCode = trpc.demoAccount.changeCode.useMutation();
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (newCode.length !== 6 || confirmCode.length !== 6 || currentCode.length !== 6) { setError("Saisissez trois codes de 6 chiffres."); return; }
    if (newCode !== confirmCode) { setError("Les deux nouveaux codes ne correspondent pas."); return; }
    try { await changeCode.mutateAsync({ accountPhone, currentCode, newCode, confirmCode }); onSuccess(); } catch (cause) { setError(cause instanceof Error ? cause.message : "Impossible de modifier le code."); }
  }
  return <div className="about-backdrop" role="dialog" aria-modal="true" aria-labelledby="change-code-title"><section className="about-panel"><div className="about-header"><div><p className="eyebrow">Sécurité du compte</p><h2 id="change-code-title">Modifier le code</h2></div><button className="sheet-close" onClick={onClose}>Fermer</button></div><form className="auth-form change-code-form" onSubmit={submit}><label>Code actuel<input type="password" inputMode="numeric" maxLength={6} value={currentCode} onChange={(event) => setCurrentCode(event.target.value.replace(/[^0-9]/g, ""))} placeholder="6 chiffres" /></label><label>Nouveau code<input type="password" inputMode="numeric" maxLength={6} value={newCode} onChange={(event) => setNewCode(event.target.value.replace(/[^0-9]/g, ""))} placeholder="6 chiffres" /></label><label>Confirmer le nouveau code<input type="password" inputMode="numeric" maxLength={6} value={confirmCode} onChange={(event) => setConfirmCode(event.target.value.replace(/[^0-9]/g, ""))} placeholder="Répétez les 6 chiffres" /></label>{error && <p className="auth-error" role="alert">{error}</p>}<button className="auth-button" type="submit" disabled={changeCode.isPending}>{changeCode.isPending ? "Mise à jour…" : "Enregistrer le nouveau code"}</button></form></section></div>;
}

export function AdminDashboard({ onLogout }: { onLogout: () => void }) {
  const [filter, setFilter] = useState<"all" | "deposit" | "withdrawal">("all");
  const utils = trpc.useUtils();
  const transactionsQuery = trpc.admin.transactions.useQuery(undefined, { refetchInterval: ADMIN_REFETCH_INTERVAL_MS });
  const updateStatus = trpc.admin.updateStatus.useMutation({ onSuccess: () => { if (shouldRefreshAfterAdminMutation()) void utils.admin.transactions.invalidate(); } });
  const visible = (transactionsQuery.data || []).filter(item => filter === "all" || item.type === filter);
  return <main className="admin-shell"><section className="admin-card"><div className="admin-header"><div><p className="eyebrow">Espace sécurisé</p><h1>Administration Anywheel</h1><p>Suivi et traitement des demandes.</p></div><button className="sheet-close" onClick={onLogout}>Déconnexion</button></div><div className="admin-notice">Les coordonnées complètes sont visibles uniquement dans cet espace. Les validations mettent à jour le statut des demandes dans le registre administratif.</div><div className="admin-filters"><button className={filter === "all" ? "active" : ""} onClick={() => setFilter("all")}>Toutes</button><button className={filter === "deposit" ? "active" : ""} onClick={() => setFilter("deposit")}>Dépôts</button><button className={filter === "withdrawal" ? "active" : ""} onClick={() => setFilter("withdrawal")}>Retraits</button></div><div className="admin-list">{transactionsQuery.isLoading ? <div className="admin-empty">Chargement des demandes…</div> : visible.length === 0 ? <div className="admin-empty">Aucune demande enregistrée.</div> : visible.map(item => <article className="admin-transaction" key={item.id}><div><strong>{item.type === "deposit" ? "Dépôt Wave" : "Retrait"}</strong><span>{new Date(item.createdAt).toLocaleString("fr-FR")}</span><span>Coordonnée : {item.phone}</span></div><div className="admin-amount">{item.amount.toLocaleString("fr-FR")} FCFA</div><div className={`status-pill ${item.status}`}>{item.status === "pending" ? "En attente" : item.status === "approved" ? "Validé" : "Refusé"}</div><div className="admin-actions"><button disabled={updateStatus.isPending} onClick={() => updateStatus.mutate({ id: item.id, status: "approved" })}>Valider</button><button disabled={updateStatus.isPending} onClick={() => updateStatus.mutate({ id: item.id, status: "rejected" })}>Refuser</button><button disabled={updateStatus.isPending} onClick={() => updateStatus.mutate({ id: item.id, status: "pending" })}>En attente</button></div></article>)}</div></section></main>;
}

function AuthLoading() {
  return <main className="auth-screen"><div className="auth-card"><div className="auth-spinner" /><p>Vérification de votre session…</p></div></main>;
}

function AuthGate({ onSuccess }: { onSuccess: (accountLabel: string) => void }) {
  const [phone, setPhone] = useState("+225 ");
  const [code, setCode] = useState("");
  const [confirmCode, setConfirmCode] = useState("");
  const referralCodeFromUrl = new URLSearchParams(window.location.search).get("code")?.trim() || "";
  const [invite, setInvite] = useState(referralCodeFromUrl);
  const [mode, setMode] = useState<"login" | "register">(referralCodeFromUrl ? "register" : "login");
  const [error, setError] = useState("");
  const signIn = trpc.demoAccount.signIn.useMutation();
  const verifyAdmin = trpc.admin.verifyDemo.useMutation();

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const normalized = normalizeIvorianPhone(phone);
    const validationError = validateAccessForm({ phone, code, confirmCode, invite, mode });
    if (validationError) { setError(validationError); return; }
    const label = normalized.replace("+", "");
    const adminResult = await verifyAdmin.mutateAsync({ phone: normalized, code });
    if (adminResult.authorized) {
      localStorage.setItem("anywheel-demo-account", "admin:session");
      localStorage.setItem("anywheel-admin", "true");
      onSuccess("admin:session");
      return;
    }
    try {
      await signIn.mutateAsync({ mode, phone: normalized, code, confirmCode: mode === "register" ? confirmCode : code, inviteCode: mode === "register" ? invite : "login" });
      localStorage.setItem("anywheel-demo-account", label);
      onSuccess(label);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Impossible d’enregistrer le compte pour le moment. Réessayez.");
    }
  }

  return <main className="auth-screen"><div className="auth-card"><div className="auth-logo"><span className="brand-dot" /> anywheel</div><h1>{mode === "login" ? "Connexion" : "Créer un compte"}</h1><p>Utilisez votre numéro ivoirien et votre code de connexion.</p><div className="auth-tabs"><button className={mode === "login" ? "active" : ""} onClick={() => { setMode("login"); setError(""); }}>Se connecter</button><button className={mode === "register" ? "active" : ""} onClick={() => { setMode("register"); setError(""); }}>S’inscrire</button></div><form className="auth-form" onSubmit={submit}><label>Numéro ivoirien<input type="tel" inputMode="tel" value={phone} onChange={(event) => setPhone(event.target.value)} placeholder="+225 07 00 00 00 00" /></label><label>Code de connexion<input type="password" inputMode="numeric" maxLength={6} value={code} onChange={(event) => setCode(event.target.value.replace(/[^0-9]/g, ""))} placeholder="6 chiffres" /></label>{mode === "register" && <><label>Confirmer le code de connexion<input type="password" inputMode="numeric" maxLength={6} value={confirmCode} onChange={(event) => setConfirmCode(event.target.value.replace(/[^0-9]/g, ""))} placeholder="Répétez les 6 chiffres" /></label><label>Code d’invitation<input value={invite} onChange={(event) => setInvite(event.target.value)} placeholder="Ex. d9s3p7" /></label></>}{error && <p className="auth-error" role="alert">{error}</p>}<div className="auth-disclaimer"><strong>Information importante</strong><span>Le numéro et les codes sont vérifiés par l’application. Les demandes sont enregistrées dans votre espace personnel et traitées selon les conditions du service.</span></div><button className="auth-button" type="submit" disabled={signIn.isPending}>{signIn.isPending ? "Vérification…" : mode === "login" ? "Se connecter" : "Créer mon compte"} <ChevronRight size={18} /></button></form><small>L’application vérifie vos identifiants pour sécuriser l’accès à votre espace personnel.</small></div></main>;
}

export function AnnouncementModal({ onClose }: { onClose: () => void }) {
  return <div className="announcement-backdrop" role="dialog" aria-modal="true" aria-labelledby="announcement-title" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}><div className="announcement-modal"><div className="announcement-kicker">Annonce officielle</div><h2 id="announcement-title">Anywheel Côte d’Ivoire : lancement officiel !</h2><p>Une toute nouvelle expérience commence le 18 août 2026.</p><div className="announcement-lines"><span>Bonus d'inscription : 1 500 FCFA</span><span>Connexion quotidienne : 50 FCFA</span><span>Commission annoncée : 39 %</span><span>Rendement annoncé : 25 % à 40 %</span></div><small>Annonce promotionnelle. Consultez les conditions des produits et le statut de vos demandes depuis votre espace personnel.</small><button className="auth-button" onClick={onClose}>Accéder à l’accueil <ChevronRight size={18} /></button></div></div>;
}

export function ActionSheet({ action, accountLabel, hasPurchased = false, entries = [], onWithdrawalHistoryPage, onClose, onCheckin, onTransaction }: { action: string; accountLabel?: string; hasPurchased?: boolean; entries?: Array<{ id: number; kind: string; direction: string; amount: number; detail: string; createdAt: Date; phone?: string; status?: string; type?: string }>; onWithdrawalHistoryPage?: () => void; onClose: () => void; onCheckin?: () => { claimed: boolean; bonusTotal: number }; onTransaction?: () => void }) {
  const copy = getActionMessage(action);
  const [pack, setPack] = useState("3000");
  const [depositPhone, setDepositPhone] = useState("+225 ");
  const [wavePhone, setWavePhone] = useState("+225 ");
  const [amount, setAmount] = useState("1500");
  const [status, setStatus] = useState("");
  const [showWithdrawalHistory, setShowWithdrawalHistory] = useState(false);
  const createTransaction = trpc.demoAccount.createTransaction.useMutation();

  async function submitDeposit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const phone = depositPhone.replace(/\s/g, "");
    if (!isValidWavePhone(phone)) { setStatus("Entrez un numéro Wave ivoirien valide pour le dépôt."); return; }
    const selectedAmount = Number(pack);
    await createTransaction.mutateAsync({ accountPhone: `+${accountLabel}`, type: "deposit", phone, amount: selectedAmount });
    onTransaction?.();
    setStatus(`Dépôt Wave de ${selectedAmount.toLocaleString("fr-FR")} FCFA enregistré pour traitement.`);
    window.location.href = getWaveDepositUrl(selectedAmount);
  }

  async function submitWithdrawal(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const phone = wavePhone.replace(/\s/g, "");
    const numericAmount = Number(amount);
    const validationError = validateWaveWithdrawal(phone, numericAmount);
    if (validationError) { setStatus(validationError); return; }
    await createTransaction.mutateAsync({ accountPhone: `+${accountLabel}`, type: "withdrawal", phone, amount: numericAmount });
    onTransaction?.();
    const fee = calculateWithdrawalFee(numericAmount);
    const net = calculateWithdrawalNet(numericAmount);
    setStatus(`Retrait de ${numericAmount.toLocaleString("fr-FR")} FCFA enregistré. Frais : ${fee.toLocaleString("fr-FR")} FCFA (20 %). Net à recevoir : ${net.toLocaleString("fr-FR")} FCFA. Traitement sous 4 à 24 heures.`);
  }

  return <div className="action-backdrop" role="dialog" aria-modal="true"><div className="action-sheet"><div className="sheet-handle" /><h2>{action}</h2>{action !== "Retrait" && <p>{copy}</p>}{action === "Recharge" && <form className="wave-form" onSubmit={submitDeposit}><label>Numéro Wave du dépôt<input type="tel" inputMode="tel" value={depositPhone} onChange={(event) => setDepositPhone(event.target.value)} placeholder="+225 07 00 00 00 00" /></label><label>Montant du pack<select value={pack} onChange={(event) => setPack(event.target.value)}><option value="3000">3 000 FCFA</option><option value="5000">5 000 FCFA</option><option value="10000">10 000 FCFA</option><option value="25000">25 000 FCFA</option></select></label><div className="wave-note">Le dépôt est effectué par Wave. Vérifiez le numéro et le montant avant validation.</div><button className="auth-button" type="submit">Valider et payer avec Wave</button></form>}{action === "Retrait" && <><form className="wave-form" onSubmit={submitWithdrawal}><label>Numéro du retrait<input type="tel" inputMode="tel" value={wavePhone} onChange={(event) => setWavePhone(event.target.value)} placeholder="+225 07 00 00 00 00" /></label><label>Montant du retrait en FCFA<input type="number" min="1500" step="1" value={amount} onChange={(event) => setAmount(event.target.value)} placeholder="Saisissez le montant" /></label><div className="withdrawal-note">Minimum : 1 500 FCFA. Frais : 20 % du montant retiré. Retraits disponibles à tout moment, traitement sous 4 à 24 heures.</div>{Number(amount) >= 1500 && <div className="withdrawal-fee-summary">Frais estimés : {calculateWithdrawalFee(Number(amount)).toLocaleString("fr-FR")} FCFA · Net à recevoir : {calculateWithdrawalNet(Number(amount)).toLocaleString("fr-FR")} FCFA</div>}{!hasPurchased && <div className="withdrawal-eligibility" role="status">Achetez au moins un produit pour activer les retraits.</div>}<button className="auth-button" type="submit" disabled={!hasPurchased}>Soumettre le retrait</button></form><button className="history-action-button" type="button" onClick={() => onWithdrawalHistoryPage?.() ?? setShowWithdrawalHistory(true)}>Historique</button></>}{action === "Pointage" && <button className="auth-button" onClick={() => { const result = onCheckin?.(); setStatus(result?.claimed ? `+50 FCFA ajoutés au solde. Bonus cumulé : ${result.bonusTotal.toLocaleString("fr-FR")} FCFA.` : "Le pointage du jour a déjà été effectué."); }}>Pointer aujourd’hui (+50 FCFA)</button>}{action !== "Recharge" && action !== "Retrait" && action !== "Pointage" && <p className="action-copy">{copy}</p>}{status && <div className="wave-status" role="status">{status}</div>}<button className="sheet-close" onClick={onClose}>Fermer</button></div>{showWithdrawalHistory && <HistoryPanel title="Historique des retraits" eyebrow="Retrait" entries={entries.filter(entry => entry.kind === "withdrawal")} onClose={() => setShowWithdrawalHistory(false)} />}</div>;
}

export function QuickAction({ icon, label, onClick }: { icon: React.ReactNode; label: string; onClick: () => void }) {
  return <button className="quick-action" onClick={onClick}><span className="quick-icon">{icon}</span><span>{label}</span></button>;
}

function NavItem({ active, icon, label, onClick }: { active: boolean; icon: React.ReactNode; label: string; onClick: () => void }) {
  return <button className={`nav-item ${active ? "active" : ""}`} onClick={onClick}>{icon}<span>{label}</span></button>;
}

function HomePanel({ onNavigate, onCopy, inviteCode, balanceCfa, cumulativeRevenueCfa, referralRevenueCfa }: { onNavigate: (tab: Tab) => void; onCopy: () => void; inviteCode: string; balanceCfa: number; cumulativeRevenueCfa: number; referralRevenueCfa: number }) {
  return (
    <>
      <section className="notice-row"><Bell size={19} fill="currentColor" /><span><b>669</b> a rechargé 3 000 FCFA · <b>****3478</b> a rechargé</span><ChevronRight size={16} /></section>
      <section className="metrics-grid">
        <MetricCard title="Solde du compte" value={`FCFA ${balanceCfa.toLocaleString("fr-FR")}`} icon={<WalletCards />} />
        <MetricCard title="Revenus cumulés" value={`FCFA ${cumulativeRevenueCfa.toLocaleString("fr-FR")}`} icon={<DollarSign />} />
        <MetricCard title="Gains de parrainage" value="Voir Équipe" icon={<UsersRound />} />
      </section>
      <section className="section-heading"><p>Emplacements</p><h2>Notre ville</h2></section>
      <div className="city-grid"><div className="city-tile"><Bike size={24} /><span>Mobilité</span></div><div className="city-tile"><UsersRound size={24} /><span>Communauté</span></div><div className="city-tile"><WalletCards size={24} /><span>Portefeuille</span></div><div className="city-tile"><DollarSign size={24} /><span>Avantages</span></div></div>
      <section className="invite-card">
        <div className="invite-visual" aria-hidden="true"><UsersRound size={42} /></div>
        <div><h2>Commencez à inviter vos amis</h2><p>Partagez le code ou le lien d’invitation.</p><div className="invite-code">{inviteCode || "Votre code"}</div><button onClick={onCopy}>Copier le lien <Copy size={15} /></button><div className="invite-link">{inviteCode ? `${window.location.origin}/reg?code=${inviteCode}` : "Lien disponible après connexion"}</div><button onClick={onCopy}>Copier <Copy size={15} /></button></div>
      </section>
      <section className="promo-copy"><strong>Informations de lancement</strong><pre>{promoText}</pre></section>
      <button className="secondary-cta" onClick={() => onNavigate("products")}>Voir les produits <ChevronRight size={17} /></button>
    </>
  );
}

function MetricCard({ title, value, icon }: { title: string; value: string; icon: React.ReactNode }) {
  return <article className="metric-card"><div className="metric-image" aria-hidden="true">{icon}</div><strong>{value}</strong><span>{title}</span></article>;
}

function ProductsPanel({ onBuy, onMyProducts }: { onBuy: (product: (typeof products)[number]) => void; onMyProducts: () => void }) {
  return     <section className="products-panel"><div className="page-heading"><p>Catalogue</p><h1>Nos produits</h1><span>Consultez les conditions de chaque produit avant de confirmer votre choix.</span><button className="history-action-button" type="button" onClick={onMyProducts}>Mes produits <ChevronRight size={17} /></button></div><div className="product-list">{products.map((product) => <article className="product-card" key={product.name}><div className="product-visual" aria-hidden="true"><Bike size={52} strokeWidth={1.2} /></div><div className="product-overlay"><h2>{product.name}</h2><div className="product-specs"><p><span>Prix</span><b>FCFA {product.price}</b></p><p><span>Durée</span><b>180 jours</b></p><p><span>Revenu quotidien</span><b>FCFA {product.daily}</b></p><p><span>Revenus totaux</span><b>FCFA {product.total}</b></p></div><button onClick={() => onBuy(product)}>Acheter <ShoppingBag size={17} /></button></div></article>)}</div></section>;
}

function TeamPanel({ onCopy, referralRevenueCfa }: { onCopy: () => void; referralRevenueCfa: number }) {
  return <section className="team-panel"><div className="team-hero"><div className="team-visual" aria-hidden="true"><UsersRound size={52} strokeWidth={1.2} /></div><div><p>Votre réseau</p><h1>Invitez vos amis à rejoindre l'équipe</h1><span>Partagez votre code et suivez votre communauté.</span></div></div><div className="team-summary"><div><b>0</b><span>Utilisateurs totaux</span></div><div><b>FCFA {referralRevenueCfa.toLocaleString("fr-FR")}</b><span>Récompenses totales</span></div></div><div className="levels"><Level label="LV1" commission="36 %" /><Level label="LV2" commission="2 %" /><Level label="LV3" commission="1 %" /></div><button className="primary-cta" onClick={onCopy}>Copier mon code d'invitation <Copy size={17} /></button></section>;
}

function Level({ label, commission }: { label: string; commission: string }) {
  return <div className="level-row"><strong>{label}</strong><div><b>{commission}</b><span>Commission</span></div><div><b>0</b><span>Utilisateurs</span></div><div><b>0</b><span>Récompenses</span></div></div>;
}

export function ProfilePanel({ onAction, onHelp, onContact, onHistory, onProductsPage, onAbout, onChangeCode, onLogout, userLabel }: { onAction: (action: string) => void; onHelp: () => void; onContact: () => void; onHistory: () => void; onProductsPage: () => void; onAbout: () => void; onChangeCode: () => void; onLogout: () => Promise<void>; userLabel: string }) {
  return <section className="profile-panel"><div className="profile-avatar"><UserRound size={32} /></div><h1>Mon compte</h1><p>{userLabel}</p><div className="profile-menu"><ProfileAction icon={<WalletCards />} label="Historique des transactions" onClick={onHistory} /><ProfileAction icon={<ShoppingBag />} label="Mes produits" onClick={onProductsPage} /><ProfileAction icon={<CircleHelp />} label="Centre d'aide" onClick={onHelp} /><ProfileAction icon={<MoreHorizontal />} label="Modifier le code" onClick={onChangeCode} /><ProfileAction icon={<CircleHelp />} label="À propos de nous" onClick={onAbout} /><ProfileAction icon={<MessageCircle />} label="Nous contacter" onClick={onContact} /></div><button className="logout-button" onClick={() => void onLogout()}>Se déconnecter</button></section>;
}

function ProfileAction({ icon, label, onClick }: { icon: React.ReactNode; label: string; onClick: () => void }) {
  return <button className="profile-action" onClick={onClick}>{icon}<span>{label}</span><ChevronRight size={17} /></button>;
}
