import React from "react";

type LedgerEntry = { id: number; kind: string; direction: string; amount: number; detail: string; createdAt: Date; phone?: string; status?: string; type?: string; grossAmountCfa?: number; feeCfa?: number; netAmountCfa?: number; balanceAfterCfa?: number };

const kindLabels: Record<string, string> = { deposit: "Dépôt", withdrawal: "Retrait", revenue: "Revenu", referral: "Parrainage", checkin: "Pointage", purchase: "Achat produit", signup_bonus: "Bonus d’inscription" };

function statusLabel(status?: string) {
  if (!status) return "Comptabilisé";
  if (status === "approved") return "Validé";
  if (status === "rejected") return "Refusé";
  return "En attente";
}

function formatCfa(value: number) { return `${value.toLocaleString("fr-FR")} FCFA`; }

export function HistoryTable({ entries, title }: { entries: LedgerEntry[]; title: string }) {
  if (entries.length === 0) return <p className="history-empty">Aucune transaction enregistrée pour ce compte.</p>;
  const sortedEntries = [...entries].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime() || b.id - a.id);
  const fallbackBalances = new Map<number, number>();
  let balance = 0;
  [...sortedEntries].reverse().forEach(entry => { balance += entry.direction === "debit" ? -entry.amount : entry.amount; fallbackBalances.set(entry.id, balance); });
  return <div className="history-table-wrap"><table className="history-table"><caption className="sr-only">{title}</caption><thead><tr><th>Date</th><th>Opération</th><th>Détail</th><th>Coordonnée</th><th>Montant brut</th><th>Frais</th><th>Net</th><th>Solde après</th><th>Statut</th></tr></thead><tbody>{sortedEntries.map(entry => { const isWithdrawal = entry.kind === "withdrawal" || entry.type === "withdrawal"; const gross = entry.grossAmountCfa ?? (isWithdrawal ? entry.amount : undefined); const fee = entry.feeCfa ?? (isWithdrawal ? Math.round(entry.amount * 0.2) : 0); const net = entry.netAmountCfa ?? (isWithdrawal ? entry.amount - fee : undefined); const balanceAfter = entry.balanceAfterCfa ?? fallbackBalances.get(entry.id) ?? 0; return <tr key={entry.id}><td data-label="Date">{new Date(entry.createdAt).toLocaleString("fr-FR")}</td><td data-label="Opération"><strong>{kindLabels[entry.kind] || entry.detail}</strong></td><td data-label="Détail">{entry.detail}</td><td data-label="Coordonnée">{entry.phone || "—"}</td><td data-label="Montant brut" className={entry.direction === "debit" ? "history-debit" : "history-credit"}>{entry.direction === "debit" ? "−" : "+"}{formatCfa(gross ?? entry.amount)}</td><td data-label="Frais">{isWithdrawal ? `−${formatCfa(fee)}` : "—"}</td><td data-label="Net">{isWithdrawal ? formatCfa(net ?? 0) : "—"}</td><td data-label="Solde après"><strong>{formatCfa(balanceAfter)}</strong></td><td data-label="Statut"><span className={`history-status ${entry.status || "recorded"}`}>{statusLabel(entry.status)}</span></td></tr>; })}</tbody></table></div>;
}

export default function HistoryPanel({ entries, onClose, title = "Historique des transactions", eyebrow = "Compte personnel" }: { entries: LedgerEntry[]; onClose: () => void; title?: string; eyebrow?: string }) {
  return <div className="history-backdrop" role="dialog" aria-modal="true" aria-labelledby="history-title"><section className="history-panel"><div className="history-header"><div><p className="eyebrow">{eyebrow}</p><h2 id="history-title">{title}</h2><p className="history-subtitle">Chaque ligne présente l’évolution complète de votre solde après l’opération.</p></div><button className="sheet-close" onClick={onClose}>Fermer</button></div><HistoryTable entries={entries} title={title} /></section></div>;
}
