import React from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { HistoryTable } from "@/pages/HistoryPanel";
import { useAuth } from "@/_core/hooks/useAuth";

export default function HistoryPage({ withdrawalsOnly = false }: { withdrawalsOnly?: boolean }) {
  const [, setLocation] = useLocation();
  const { loading } = useAuth();
  const accountLabel = localStorage.getItem("anywheel-demo-account") || "";
  const isAccount = accountLabel.startsWith("225");
  const portfolioQuery = trpc.demoAccount.portfolio.useQuery({ phone: `+${accountLabel}` }, { enabled: isAccount });
  const entries = (portfolioQuery.data?.ledger ?? []).filter(entry => !withdrawalsOnly || entry.kind === "withdrawal");
  const title = withdrawalsOnly ? "Historique des retraits" : "Historique des transactions";

  if (loading || !isAccount) return <main className="history-page"><section className="history-page-card"><p className="eyebrow">Espace personnel</p><h1>{title}</h1><p className="history-page-empty">Connectez-vous pour consulter l’historique de votre compte.</p><button className="auth-button" onClick={() => setLocation("/")}>Retour à la connexion</button></section></main>;

  return <main className="history-page"><section className="history-page-card"><header className="history-page-header"><div><p className="eyebrow">Compte personnel</p><h1>{title}</h1><p>Compte : +{accountLabel}</p></div><button className="history-back-button" onClick={() => setLocation("/")}>Retour au compte</button></header>{portfolioQuery.isLoading ? <p className="history-page-empty">Chargement de votre historique…</p> : <HistoryTable entries={entries} title={title} />}</section></main>;
}
