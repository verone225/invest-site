import React from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";

export default function MyProductsPage() {
  const [, setLocation] = useLocation();
  const { loading, isAuthenticated } = useAuth();
  const accountLabel = localStorage.getItem("anywheel-demo-account") || "";
  const isAccount = accountLabel.startsWith("225");
  const purchasesQuery = trpc.demoAccount.purchases.useQuery({ phone: `+${accountLabel}` }, { enabled: isAccount });

  if (loading || !isAuthenticated || !isAccount) return <main className="history-page"><section className="history-page-card"><p className="eyebrow">Espace personnel</p><h1>Mes produits</h1><p className="history-page-empty">Connectez-vous pour consulter vos produits.</p><button className="auth-button" onClick={() => setLocation("/")}>Retour à la connexion</button></section></main>;

  return <main className="history-page"><section className="history-page-card"><header className="history-page-header"><div><p className="eyebrow">Compte personnel</p><h1>Mes produits</h1><p>Compte : +{accountLabel}</p></div><button className="history-back-button" onClick={() => setLocation("/")}>Retour au compte</button></header>{purchasesQuery.isLoading ? <p className="history-page-empty">Chargement de vos produits…</p> : purchasesQuery.isError ? <div className="history-page-empty" role="alert"><strong>Impossible de charger vos produits.</strong><p>Vérifiez votre connexion puis réessayez.</p><button className="auth-button" onClick={() => void purchasesQuery.refetch()}>Réessayer</button></div> : purchasesQuery.data?.length ? <div className="products-purchased-list">{purchasesQuery.data.map(product => <article className="purchased-product-card" key={product.id}><div><p className="purchased-product-status">{product.status === "completed" ? "Achat confirmé" : "Achat annulé"}</p><h2>{product.productName}</h2><p>Acheté le {new Date(product.createdAt).toLocaleString("fr-FR")}</p></div><strong>{product.amount.toLocaleString("fr-FR")} FCFA</strong></article>)}</div> : <div className="history-page-empty"><strong>Aucun produit acheté</strong><p>Accédez à la rubrique Produit pour choisir un produit avec le solde de votre compte.</p><button className="auth-button" onClick={() => setLocation("/")}>Voir les produits</button></div>}</section></main>;
}
