import React from "react";

type LedgerEntry = { id: number; kind: string; direction: string; amount: number; detail: string; createdAt: Date; phone?: string; status?: string; type?: string };

const kindLabels: Record<string, string> = { deposit: "Dépôt", withdrawal: "Retrait", revenue: "Revenu", referral: "Parrainage", checkin: "Pointage", purchase: "Achat produit" };

function statusLabel(status?: string) {
  if (!status) return "Comptabilisé";
  if (status === "approved") return "Validé";
  if (status === "rejected") return "Refusé";
  return "En attente";
}

export function HistoryTable({ entries, title }: { entries: LedgerEntry[]; title: string }) {
  if (entries.length === 0) return <p className="history-empty">Aucune transaction enregistrée pour ce compte.</p>;
  return <div className="history-table-wrap"><table className="history-table"><caption className="sr-only">{title}</caption><thead><tr><th>Type</th><th>Détail</th><th>Numéro</th><th>Date</th><th>Montant</th><th>Statut</th></tr></thead><tbody>{entries.map(entry => <tr key={entry.id}><td data-label="Type"><strong>{kindLabels[entry.kind] || entry.detail}</strong></td><td data-label="Détail">{entry.detail}</td><td data-label="Numéro">{entry.phone || "—"}</td><td data-label="Date">{new Date(entry.createdAt).toLocaleString("fr-FR")}</td><td data-label="Montant" className={entry.direction === "debit" ? "history-debit" : "history-credit"}>{entry.direction === "debit" ? "−" : "+"}{entry.amount.toLocaleString("fr-FR")} FCFA</td><td data-label="Statut"><span className={`history-status ${entry.status || "recorded"}`}>{statusLabel(entry.status)}</span></td></tr>)}</tbody></table></div>;
}

export default function HistoryPanel({ entries, onClose, title = "Historique des transactions", eyebrow = "Compte personnel" }: { entries: LedgerEntry[]; onClose: () => void; title?: string; eyebrow?: string }) {
  return <div className="history-backdrop" role="dialog" aria-modal="true" aria-labelledby="history-title"><section className="history-panel"><div className="history-header"><div><p className="eyebrow">{eyebrow}</p><h2 id="history-title">{title}</h2></div><button className="sheet-close" onClick={onClose}>Fermer</button></div><HistoryTable entries={entries} title={title} /></section></div>;
}
