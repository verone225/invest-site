export type AccessFormInput = {
  phone: string;
  code: string;
  confirmCode?: string;
  invite?: string;
  mode: "login" | "register";
};

export function normalizeIvorianPhone(phone: string) {
  return phone.replace(/\s/g, "");
}

export function validateAccessForm(input: AccessFormInput): string | null {
  const normalized = normalizeIvorianPhone(input.phone);
  if (!/^\+225(0[157])[0-9]{8}$/.test(normalized)) {
    return "Entrez un numéro ivoirien valide, par exemple +225 07 00 00 00 00.";
  }
  if (!/^[0-9]{6}$/.test(input.code)) {
    return "Le code de connexion doit contenir exactement 6 chiffres.";
  }
  if (input.mode === "register" && input.confirmCode !== input.code) {
    return "Les deux codes de connexion ne correspondent pas.";
  }
  if (input.mode === "register" && (input.invite ?? "").trim().length < 4) {
    return "Le code d’invitation est requis pour l’inscription.";
  }
  return null;
}
