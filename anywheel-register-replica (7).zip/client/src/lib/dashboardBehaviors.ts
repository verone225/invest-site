export const actionMessages: Record<string, string> = {
  Recharge: "Choisissez un montant et soumettez votre demande de dépôt.",
  Retrait: "Saisissez les informations nécessaires pour votre demande de retrait.",
  Aide: "Le centre d’aide vous accompagne pour votre compte et vos produits.",
  Pointage: "Validez votre présence quotidienne pour actualiser vos avantages.",
};

export const announcementStartsOpen = true;

export function dismissAnnouncement() {
  return false;
}

export function getActionMessage(action: string) {
  return actionMessages[action] || "Cette fonctionnalité est disponible depuis votre espace personnel.";
}
