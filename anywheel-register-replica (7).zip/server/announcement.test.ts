// @vitest-environment jsdom
import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { AnnouncementModal } from "../client/src/pages/Home";

describe("announcement interaction", () => {
  it("calls the close handler when the user enters the home page", () => {
    const onClose = vi.fn();
    render(React.createElement(AnnouncementModal, { onClose }));
    expect(screen.getByRole("dialog")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: /Accéder à l’accueil/i }));
    expect(onClose).toHaveBeenCalledOnce();
  });
});
