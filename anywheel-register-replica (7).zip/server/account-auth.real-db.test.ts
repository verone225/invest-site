import { afterEach, describe, expect, it } from "vitest";
import { eq } from "drizzle-orm";
import { demoAccounts, demoLedger, demoPurchases } from "../drizzle/schema";
import { getDb } from "./db";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

const phone = "+2250787654388";
const ctx = { req: { protocol: "https", headers: {} } as TrpcContext["req"], res: {} as TrpcContext["res"], user: undefined } as TrpcContext;

async function cleanup() {
  const db = await getDb();
  if (!db) return;
  await db.delete(demoPurchases).where(eq(demoPurchases.accountPhone, phone));
  await db.delete(demoLedger).where(eq(demoLedger.accountPhone, phone));
  await db.delete(demoAccounts).where(eq(demoAccounts.phone, phone));
}

describe.skipIf(!process.env.DATABASE_URL)("account authentication", () => {
  afterEach(cleanup);
  it("accepts only registered credentials", async () => {
    const caller = appRouter.createCaller(ctx);
    await caller.demoAccount.signIn({ mode: "register", phone, code: "010101", confirmCode: "010101", inviteCode: "d9s3p7" });
    await expect(caller.demoAccount.signIn({ mode: "login", phone, code: "010101", confirmCode: "010101", inviteCode: "d9s3p7" })).resolves.toMatchObject({ phone, balanceCfa: 1000, cumulativeRevenueCfa: 0 });
    await expect(caller.demoAccount.signIn({ mode: "login", phone: "+2250787654387", code: "010101", confirmCode: "010101", inviteCode: "d9s3p7" })).rejects.toThrow("incorrect");
    await expect(caller.demoAccount.signIn({ mode: "login", phone, code: "999999", confirmCode: "999999", inviteCode: "d9s3p7" })).rejects.toThrow("incorrect");
    await expect(caller.demoAccount.changeCode({ accountPhone: phone, currentCode: "999999", newCode: "121212", confirmCode: "121212" })).rejects.toThrow("ancien code");
    await expect(caller.demoAccount.changeCode({ accountPhone: phone, currentCode: "010101", newCode: "121212", confirmCode: "121213" })).rejects.toThrow("ne correspondent pas");
    await expect(caller.demoAccount.changeCode({ accountPhone: phone, currentCode: "010101", newCode: "010101", confirmCode: "010101" })).rejects.toThrow("différent");
    await expect(caller.demoAccount.changeCode({ accountPhone: phone, currentCode: "010101", newCode: "121212", confirmCode: "121212" })).resolves.toMatchObject({ phone, updated: true });
    await expect(caller.demoAccount.signIn({ mode: "login", phone, code: "010101", confirmCode: "010101", inviteCode: "d9s3p7" })).rejects.toThrow("incorrect");
    await expect(caller.demoAccount.signIn({ mode: "login", phone, code: "121212", confirmCode: "121212", inviteCode: "d9s3p7" })).resolves.toMatchObject({ phone });
  });
});
