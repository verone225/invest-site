// @vitest-environment jsdom
import React from "react";
import { render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

const setLocation = vi.fn();
const refetch = vi.fn();
const storage = new Map<string, string>();
Object.defineProperty(globalThis, "localStorage", { value: { setItem: (key: string, value: string) => storage.set(key, value), getItem: (key: string) => storage.get(key) ?? null, clear: () => storage.clear() }, configurable: true });

vi.mock("../client/src/_core/hooks/useAuth", () => ({ useAuth: () => ({ loading: false, isAuthenticated: true }) }));
vi.mock("wouter", () => ({ useLocation: () => ["/my-products", setLocation] }));
vi.mock("../client/src/lib/trpc", () => ({ trpc: { demoAccount: { purchases: { useQuery: () => ({ data: [{ id: 1, productName: "VIP2 Anywheel Bike", amount: 5000, status: "completed", createdAt: new Date("2026-08-18T10:00:00Z") }], isLoading: false, isError: false, refetch }) } } } }));

import MyProductsPage from "../client/src/pages/MyProductsPage";

afterEach(() => {
  localStorage.clear();
  document.body.innerHTML = "";
  setLocation.mockClear();
});

describe("My products page", () => {
  it("affiche un achat VIP avec son montant et son statut", () => {
    localStorage.setItem("anywheel-demo-account", "2250700000000");
    render(React.createElement(MyProductsPage));
    expect(screen.getByRole("heading", { name: "Mes produits" })).toBeTruthy();
    expect(screen.getByRole("heading", { name: "VIP2 Anywheel Bike" })).toBeTruthy();
    expect(screen.getByText(/5\s?000 FCFA/)).toBeTruthy();
    expect(screen.getByText("Achat confirmé")).toBeTruthy();
  });

  it("propose de revenir au compte", () => {
    localStorage.setItem("anywheel-demo-account", "2250700000000");
    render(React.createElement(MyProductsPage));
    screen.getByRole("button", { name: "Retour au compte" }).click();
    expect(setLocation).toHaveBeenCalledWith("/");
  });
});
