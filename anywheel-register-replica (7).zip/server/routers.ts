import { createHash } from "node:crypto";
import { z } from "zod";
import { createDemoAccount, createDemoPurchase, createDemoTransaction, creditReferralRevenue, getDemoAccountByPhone, getPortfolioSummary, hasCompletedPurchase, listDemoPurchases, listDemoTransactions, listLedgerByAccount, updateDemoAccountCode, updateDemoTransactionStatus } from "./db";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { COOKIE_NAME as ADMIN_COOKIE_NAME, MAX_AGE_SECONDS, createAdminSession, hasValidAdminSession } from "./adminSession";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  admin: router({
    verifyDemo: publicProcedure.input(z.object({ phone: z.string(), code: z.string() })).mutation(({ input, ctx }) => {
      const authorized = input.phone.replace(/\s/g, "") === "+2250544894579" && input.code === "010101";
      if (authorized) { const session = createAdminSession("+2250544894579"); ctx.res.cookie(ADMIN_COOKIE_NAME, session.value, { ...getSessionCookieOptions(ctx.req), maxAge: session.maxAge * 1000 }); }
      return { authorized };
    }),
    me: publicProcedure.query(({ ctx }) => ({ authorized: hasValidAdminSession(ctx.req.headers.cookie) })),
    transactions: publicProcedure.query(async ({ ctx }) => {
      if (!hasValidAdminSession(ctx.req.headers.cookie)) throw new TRPCError({ code: "UNAUTHORIZED", message: "Accès administrateur refusé." });
      return listDemoTransactions();
    }),
    updateStatus: publicProcedure.input(z.object({ id: z.number(), status: z.enum(["pending", "approved", "rejected"]) })).mutation(async ({ input, ctx }) => {
      if (!hasValidAdminSession(ctx.req.headers.cookie)) throw new TRPCError({ code: "UNAUTHORIZED", message: "Accès administrateur refusé." });
      return updateDemoTransactionStatus(input.id, input.status);
    }),
    creditReferral: publicProcedure.input(z.object({ accountPhone: z.string().regex(/^\+225(0[157])[0-9]{8}$/), amount: z.number().int().positive(), detail: z.string().min(3).max(255) })).mutation(async ({ input, ctx }) => {
      if (!hasValidAdminSession(ctx.req.headers.cookie)) throw new TRPCError({ code: "UNAUTHORIZED", message: "Accès administrateur refusé." });
      return creditReferralRevenue(input.accountPhone, input.amount, input.detail);
    }),
  }),
  demoAccount: router({
    signIn: publicProcedure.input(z.object({ mode: z.enum(["login", "register"]).default("login"), phone: z.string().regex(/^\+225(0[157])[0-9]{8}$/), code: z.string().regex(/^[0-9]{6}$/), confirmCode: z.string().regex(/^[0-9]{6}$/), inviteCode: z.string().min(4) })).mutation(async ({ input }) => {
      const codeHash = createHash("sha256").update(input.code).digest("hex");
      if (input.mode === "register") {
        if (input.code !== input.confirmCode) throw new TRPCError({ code: "BAD_REQUEST", message: "Les deux codes de connexion ne correspondent pas." });
        const existing = await getDemoAccountByPhone(input.phone);
        if (existing) throw new TRPCError({ code: "CONFLICT", message: "Ce numéro est déjà inscrit. Connectez-vous avec vos identifiants." });
        const account = await createDemoAccount({ phone: input.phone, codeHash, inviteCode: input.inviteCode });
        return { phone: input.phone, balanceCfa: account?.balanceCfa ?? 1500, cumulativeRevenueCfa: account?.cumulativeRevenueCfa ?? 0, simulated: true };
      }
      const account = await getDemoAccountByPhone(input.phone);
      if (!account || account.codeHash !== codeHash) throw new TRPCError({ code: "UNAUTHORIZED", message: "Numéro ou code de connexion incorrect." });
      return { phone: account.phone, balanceCfa: account.balanceCfa, cumulativeRevenueCfa: account.cumulativeRevenueCfa, simulated: true };
    }),
    changeCode: publicProcedure.input(z.object({ accountPhone: z.string().regex(/^\+225(0[157])[0-9]{8}$/), currentCode: z.string().regex(/^[0-9]{6}$/), newCode: z.string().regex(/^[0-9]{6}$/), confirmCode: z.string().regex(/^[0-9]{6}$/) })).mutation(async ({ input }) => {
      if (input.newCode !== input.confirmCode) throw new TRPCError({ code: "BAD_REQUEST", message: "Les deux nouveaux codes ne correspondent pas." });
      if (input.currentCode === input.newCode) throw new TRPCError({ code: "BAD_REQUEST", message: "Le nouveau code doit être différent de l’ancien." });
      const account = await getDemoAccountByPhone(input.accountPhone);
      const currentHash = createHash("sha256").update(input.currentCode).digest("hex");
      if (!account || account.codeHash !== currentHash) throw new TRPCError({ code: "UNAUTHORIZED", message: "L’ancien code est incorrect." });
      const newHash = createHash("sha256").update(input.newCode).digest("hex");
      const updated = await updateDemoAccountCode(input.accountPhone, newHash);
      return { phone: updated?.phone ?? input.accountPhone, updated: true };
    }),
    purchaseProduct: publicProcedure.input(z.object({ accountPhone: z.string().regex(/^\+225(0[157])[0-9]{8}$/), productName: z.string().min(2).max(100), amount: z.number().int().positive() })).mutation(async ({ input }) => {
      const account = await getDemoAccountByPhone(input.accountPhone);
      if (!account) throw new TRPCError({ code: "BAD_REQUEST", message: "Compte utilisateur introuvable." });
      return createDemoPurchase(input);
    }),
    purchases: publicProcedure.input(z.object({ phone: z.string().regex(/^\+225(0[157])[0-9]{8}$/) })).query(async ({ input }) => listDemoPurchases(input.phone)),
    createTransaction: publicProcedure.input(z.object({ accountPhone: z.string().regex(/^\+225(0[157])[0-9]{8}$/), type: z.enum(["deposit", "withdrawal"]), phone: z.string().regex(/^\+225(0[157])[0-9]{8}$/), amount: z.number().int().positive() })).mutation(async ({ input }) => {
      const account = await getDemoAccountByPhone(input.accountPhone);
      if (!account) throw new TRPCError({ code: "BAD_REQUEST", message: "Compte utilisateur introuvable." });
      if (input.type === "withdrawal") {
        if (input.amount < 1500) throw new TRPCError({ code: "BAD_REQUEST", message: "Le montant minimum de retrait est de 1 500 FCFA." });
        if (!(await hasCompletedPurchase(input.accountPhone))) throw new TRPCError({ code: "FORBIDDEN", message: "Achetez au moins un produit avant de demander un retrait." });
      }
      return { ...(await createDemoTransaction(input)), simulated: true };
    }),
    portfolio: publicProcedure.input(z.object({ phone: z.string().regex(/^\+225(0[157])[0-9]{8}$/) })).query(async ({ input }) => {
      const summary = await getPortfolioSummary(input.phone);
      const hasPurchased = await hasCompletedPurchase(input.phone);
      return { phone: input.phone, balanceCfa: summary.account?.balanceCfa ?? 1500, cumulativeRevenueCfa: summary.totalRevenueCfa ?? 0, referralRevenueCfa: summary.referralRevenueCfa, hasPurchased, ledger: summary.ledger, simulated: true };
    }),
    history: publicProcedure.input(z.object({ phone: z.string().regex(/^\+225(0[157])[0-9]{8}$/) })).query(async ({ input }) => listLedgerByAccount(input.phone)),
  }),
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
