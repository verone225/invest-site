// @vitest-environment jsdom
import React from "react";
import { cleanup, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
afterEach(() => cleanup());
vi.mock("../client/src/lib/trpc", () => ({ trpc: { demoAccount: { createTransaction: { useMutation: () => ({ mutateAsync: vi.fn() }) } } } }));
import { ActionSheet } from "../client/src/pages/Home";

describe("Wave deposit selector", () => {
  it("shows the available deposit amounts including VIP 5 000 FCFA", () => {
    render(React.createElement(ActionSheet, { action: "Recharge", onClose: vi.fn() }));
    const options = Array.from(document.querySelectorAll("select option")).map(option => option.textContent);
    expect(options).toEqual(["3 000 FCFA", "5 000 FCFA", "10 000 FCFA", "25 000 FCFA"]);
    expect(screen.getByText(/dépôt est effectué par Wave/i)).toBeTruthy();
  });

  it("keeps the withdrawal sheet limited to its form controls", () => {
    render(React.createElement(ActionSheet, { action: "Retrait", onClose: vi.fn() }));
    expect(screen.getByRole("heading", { name: "Retrait" })).toBeTruthy();
    expect(document.querySelectorAll("input")).toHaveLength(2);
    const submitButton = screen.getByRole("button", { name: /Soumettre le retrait/i });
    expect(submitButton).toBeTruthy();
    expect((submitButton as HTMLButtonElement).disabled).toBe(true);
    expect(screen.getByText(/Achetez au moins un produit pour activer les retraits/i)).toBeTruthy();
    expect(screen.getByRole("button", { name: "Historique" })).toBeTruthy();
    expect(screen.queryByText(/Wave/i)).toBeNull();
  });
});
